import com.starksystem.ws.StarkSystemService;
import com.starksystem.dao.DAOPedido;
import com.starksystem.modelo.Pedido;
public class VerificarTotalStark {
 public static void main(String[] args) throws Exception {
  StarkSystemService service=new StarkSystemService();
  final double[] gravado={-1};
  DAOPedido dao=new DAOPedido(){public Pedido insert(Pedido p){gravado[0]=p.getTotal();p.setCodigo("TESTE");return p;}};
  java.lang.reflect.Field field=StarkSystemService.class.getDeclaredField("dao");field.setAccessible(true);field.set(service,dao);
  for(double total:new double[]{4590.0,16740.0,65073.59}) {
   Pedido p=new Pedido();p.setTotal(total);Pedido resposta=service.inserirPedido(p);
   if(gravado[0]!=total||resposta.getTotal()!=total) throw new AssertionError("Total alterado");
  }
  for(Double invalido:new Double[]{null,-1.0,Double.NaN,Double.POSITIVE_INFINITY}) {
   Pedido p=new Pedido();p.setTotal(invalido);
   try{service.inserirPedido(p);throw new AssertionError("Total invalido aceito");}catch(IllegalArgumentException esperado){}
  }
  System.out.println("PASS: StarkSystem preserva o total recebido no DAO e no retorno; valores invalidos rejeitados. Sem escrita no banco real.");
 }
}