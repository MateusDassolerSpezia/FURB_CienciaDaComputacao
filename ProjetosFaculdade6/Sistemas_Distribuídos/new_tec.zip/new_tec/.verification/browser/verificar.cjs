
const { chromium }=require('playwright-core');
const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert');
const root=path.resolve('new_tec/src/main/app/docroot');
let recebido;
const server=http.createServer((req,res)=>{
 if(req.method==='POST'){let b='';req.on('data',d=>b+=d);req.on('end',()=>{recebido=new URLSearchParams(b);res.setHeader('Content-Type','text/plain; charset=UTF-8');res.end('Pedido de teste recebido.');});return;}
 const p=path.resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]==='/'?'/index.html':req.url.split('?')[0]));
 if(!p.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
 fs.readFile(p,(e,b)=>{if(e){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',p.endsWith('.css')?'text/css; charset=UTF-8':p.endsWith('.html')?'text/html; charset=UTF-8':p.endsWith('.png')?'image/png':'image/jpeg');res.end(b);});
});
(async()=>{
 let browser;
 try{
  await new Promise(r=>server.listen(18087,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
  const page=await browser.newPage({viewport:{width:1440,height:1100}});
  await page.goto('http://127.0.0.1:18087/');
  const backup=fs.readdirSync('new_tec/tools/correcoes-fornecedores/backups').sort().reverse().map(d=>path.join('new_tec/tools/correcoes-fornecedores/backups',d,'index.html.bak')).find(p=>fs.existsSync(p));
  const before=fs.readFileSync(backup,'utf8');
  const compare=await page.evaluate(old=>{
   function contract(doc){const f=doc.querySelector('form');return {action:f.getAttribute('action'),method:f.getAttribute('method'),fields:Array.from(f.querySelectorAll('input[name],select[name]')).map(e=>({name:e.name,type:e.type,value:e.value,min:e.getAttribute('min'),max:e.getAttribute('max'),required:e.required,pattern:e.getAttribute('pattern'),options:e.tagName==='SELECT'?Array.from(e.options).map(o=>o.value):null})).sort((a,b)=>a.name.localeCompare(b.name))};}
   return {before:contract(new DOMParser().parseFromString(old,'text/html')),after:contract(document)};
  },before);
  assert.deepStrictEqual(compare.after,compare.before,'Contrato do formulario mudou');
  assert(await page.locator('img').evaluateAll(imgs=>imgs.every(i=>i.complete&&i.naturalWidth>0)),'Imagem ausente');
  for(const width of [1440,768,390,360]){
   await page.setViewportSize({width,height:1100});
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Overflow horizontal em '+width);
   if(width===1440||width===390)await page.screenshot({path:'new_tec/.verification/'+(width===1440?'desktop':'mobile')+'.png',fullPage:true});
  }
  await page.locator('[name=QRDRA]').fill('2');await page.locator('[name=nome]').fill('Cliente Teste');await page.locator('[name=cep]').fill('88036002');await page.locator('[name=nomeCartao]').fill('CLIENTE TESTE');await page.locator('[name=numeroCartao]').fill('4234567890123456');await page.locator('[name=dataVencimento]').fill('12/2030');
  await Promise.all([page.waitForURL('**/tratarForm'),page.getByRole('button',{name:'Enviar pedido'}).click()]);
  assert.strictEqual(recebido.get('QRDRA'),'2');assert.strictEqual(recebido.get('bandeira'),'VISA');assert.strictEqual(recebido.get('numeroCartao'),'4234567890123456');assert.strictEqual([...recebido.keys()].length,12);
  await page.goto('http://127.0.0.1:18087/');await page.locator('[name=QRSRA]').fill('5');await page.getByRole('button',{name:'Limpar formulário'}).click();assert.strictEqual(await page.locator('[name=QRSRA]').inputValue(),'0');
  console.log('PASS: contrato dos 12 campos preservado, imagens carregadas, desktop/mobile sem overflow, POST e reset funcionando. Nenhum pedido enviado a servicos reais.');
 }finally{if(browser)await browser.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
