$ErrorActionPreference='Stop'
Set-Location (Resolve-Path "$PSScriptRoot/..")
New-Item -ItemType Directory -Force new_tec/.verification/classes | Out-Null
$muleRuntime='C:/ESB/AnypointStudio/plugins/org.mule.tooling.server.3.9.5.ee_6.6.4.202212061409/mule'
$java8='C:/ESB/OpenJDK8U-jdk_x64_windows_hotspot_8u502b07/jdk8u502-b07/bin'
$testClasspath="$muleRuntime/lib/opt/*;$muleRuntime/lib/boot/*;$muleRuntime/lib/mule/*;$muleRuntime/plugins/mule-plugin-weave-3.9.5-20220920-dist/lib/*;new_tec/lib/*;new_tec/.verification/classes;new_tec/src/main/app;new_tec/src/main/resources"
$sourceFiles=Get-ChildItem new_tec/src/main/java/br/furb/dsc -Filter '*.java' | ForEach-Object {$_.FullName}
& "$java8/javac.exe" -encoding UTF-8 -cp $testClasspath -d new_tec/.verification/classes $sourceFiles new_tec/tools/verificacao/VerificarIntegracao.java
if($LASTEXITCODE -ne 0) { throw 'Compilacao falhou' }
$ErrorActionPreference='Continue'
& "$java8/java.exe" "-Dmule.home=$muleRuntime" "-Dmule.base=$pwd/new_tec/.verification" "-Dapp.home=$pwd/new_tec/src/main/app" -cp $testClasspath br.furb.dsc.VerificarIntegracao *> new_tec/.verification/verificacao.log
$resultado=$LASTEXITCODE
$ErrorActionPreference='Stop'
Get-Content new_tec/.verification/verificacao.log -Tail 45
if($resultado -ne 0) { throw "Verificacao falhou: $resultado" }
