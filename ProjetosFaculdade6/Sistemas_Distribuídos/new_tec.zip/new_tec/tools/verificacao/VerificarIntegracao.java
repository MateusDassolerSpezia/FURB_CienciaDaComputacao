package br.furb.dsc;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.rmi.registry.*;
import java.rmi.server.UnicastRemoteObject;
import com.sun.net.httpserver.*;
import org.mule.api.MuleContext;
import org.mule.context.DefaultMuleContextFactory;
import br.com.newtec.calculocomissao.CalculoComissaoService;
public class VerificarIntegracao {
 static int pagamentos=0,fornecedores=0; static boolean falhar=false,cepVazio=false;
 static void check(boolean v,String msg) { if(!v) throw new AssertionError(msg); }
 static Map<String,String> form(String numero) {
  Map<String,String> f=new HashMap<>(); f.put("nome","Cliente Teste");f.put("cep","88036002");f.put("QRDRS","4");
  f.put("nomeCartao","CLIENTE TESTE");f.put("numeroCartao",numero);f.put("dataVencimento","12/2099");
  f.put("bandeira",numero.startsWith("4")?"VISA":"MASTERCARD");return f;
 }
 static void responder(HttpExchange ex,int status,String texto) throws IOException {
  byte[] data=texto.getBytes(StandardCharsets.UTF_8);ex.getResponseHeaders().set("Content-Type","text/xml; charset=UTF-8");
  ex.sendResponseHeaders(status,data.length);ex.getResponseBody().write(data);ex.close();
 }
 static String ler(InputStream in) throws IOException { ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] v=new byte[4096];int n;while((n=in.read(v))!=-1)b.write(v,0,n);return b.toString("UTF-8"); }
 static String request(String numero, boolean invalido, int esperado) throws Exception {
  Map<String,String> f=form(numero);if(invalido)f.put("cep","123");
  StringJoiner b=new StringJoiner("&");for(Map.Entry<String,String> e:f.entrySet())b.add(URLEncoder.encode(e.getKey(),"UTF-8")+"="+URLEncoder.encode(e.getValue(),"UTF-8"));
  HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:18185/tratarForm").openConnection();
  c.setReadTimeout(60000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
  c.getOutputStream().write(b.toString().getBytes(StandardCharsets.UTF_8));int status=c.getResponseCode();
  String resposta=ler(status>=400?c.getErrorStream():c.getInputStream());c.disconnect();
  check(status==esperado,"HTTP "+status+": "+resposta);return resposta;
 }
 static ServerSocket cartao(boolean visa) throws Exception {
  ServerSocket server=new ServerSocket(visa?18900:18901,10,InetAddress.getByName("127.0.0.1"));
  Thread t=new Thread(()->{while(!server.isClosed())try(Socket s=server.accept()) {
   s.setSoTimeout(10000);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));
   PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true);
   out.println(visa?"Visa Payment Service":"Mastercard Payment Service");
   check((visa?"PAY":"PAYMENT").equals(in.readLine()),"Comando inicial cartao");out.println("OK");
   int partes=visa?1:4;for(int i=0;i<partes;i++){String part=in.readLine();check(part.length()==(visa?16:4),"Parte cartao");out.println(visa?"OK":"PROCEED");}
   String nome=in.readLine();out.println(visa?"OK":"PROCEED");String validade=in.readLine();out.println(visa?"OK":"PROCEED");
   String valor=in.readLine();check(valor.matches("[0-9]+\\.[0-9]{2}"),"Formato valor: "+valor);out.println(visa?"OK":"PROCEED");
   check("COMMIT".equals(in.readLine()),"COMMIT");out.println("OK");pagamentos++;
   String liquido=String.format(Locale.US,"%.2f",Double.parseDouble(valor)*(visa?.95:.97));
   out.println(visa?"teste-visa:"+nome+":123456:"+validade+":"+valor+":"+liquido:"teste-master:123456:"+valor+":"+liquido);
  }catch(Exception e){if(!server.isClosed())e.printStackTrace();}});t.setDaemon(true);t.start();return server;
 }
 public static void main(String[] args) throws Exception {
  MuleContext context=null; HttpServer http=null;ServerSocket visa=null,master=null;Registry registry=null;CalculoComissaoService service=null;
  try {
   IntegracaoPedido integracao=new IntegracaoPedido();Pedido p=new Tratamento().tratarDados(form("4234567890123456"));
   PedidoReator reator=integracao.prepararReator(p);PedidoRobo robo=integracao.prepararRobo(p);
   check(reator.getTotal()==4590,"Solar: quantidade e B2B");check(robo.getTotal()==2295,"Domestico: quantidade e B2B");
   check(integracao.subtotal(p)==6885,"Subtotal");p.setFrete(29);integracao.consolidar(p,7573.5f);
   check(p.getComissao()==1032.75 && p.getTotal()==7946.75,"Comissao 15% e frete");
   Map<String,String> tres=form("4234567890123456");tres.put("QRDRS","3");Pedido t=new Tratamento().tratarDados(tres);
   check(integracao.prepararRobo(t).getTotal()==2295,"3 unidades sem desconto de quantidade");
   check(integracao.prepararReator(t).getTotal()==4050,"3 reatores sem desconto de quantidade");
   Map<String,String> misto=form("4234567890123456");misto.put("QRDRS","0");misto.put("QRDRA","2");misto.put("QRSRA","4");misto.put("QRMRS","4");
   Pedido m=new Tratamento().tratarDados(misto);check(m.getqReatorArk()==6 && m.getqReatorSolar()==4,"Agregacao reatores");
   check(integracao.prepararRobo(m).getTotal()==14382,"Descontos seguranca e medico");
   check(integracao.prepararReator(m).getTotal()==16740,"Descontos Ark e Solar");
   System.out.println("PASS: calculos, limites e agregacao");
   http=HttpServer.create(new InetSocketAddress("127.0.0.1",18080),0);
   http.createContext("/CEPService/getCepInfo/",ex->{if(!"GET".equals(ex.getRequestMethod())) { responder(ex,405,"Consulta deve usar GET"); return; } if(cepVazio) { ex.sendResponseHeaders(204,-1); ex.close(); return; } responder(ex,200,"{\"uf\":\"SC\",\"logradouro\":\"Rua Teste\",\"bairro\":\"Centro\",\"localidade\":\"Blumenau\"}");});
   http.createContext("/StarkSystem/StarkSystemService",ex->{String body=ler(ex.getRequestBody());check(body.contains("4590"),"Total enviado SOAP");fornecedores++;responder(ex,200,"<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body><ns2:inserirPedidoResponse xmlns:ns2=\"http://ws.starksystem.com/\"><return><codigo>STK-TESTE</codigo><total>4590.0</total></return></ns2:inserirPedidoResponse></S:Body></S:Envelope>");});
   http.createContext("/BrRobotics/rest/BrRoboticsService/inserirPedido",ex->{String body=ler(ex.getRequestBody());check(body.contains("2295"),"Total enviado REST");fornecedores++;responder(ex,falhar?500:200,falhar?"falha simulada":"{\"codigo\":\"BR-TESTE\",\"total\":2295}");});http.start();
   visa=cartao(true);master=cartao(false);
   registry=LocateRegistry.createRegistry(11999);service=v->v*1.1f;registry.rebind("CalculoComissaoService",UnicastRemoteObject.exportObject(service,0));
   System.setProperty("http.porta","18185");System.setProperty("cep.protocolo","HTTP");System.setProperty("cep.porta","18080");System.setProperty("cep.host","127.0.0.1");
   System.setProperty("fornecedores.porta","18080");System.setProperty("stark.endereco","http://127.0.0.1:18080/StarkSystem/StarkSystemService");
   System.setProperty("comissao.registry","rmi://127.0.0.1:11999");System.setProperty("comissao.endereco","rmi://127.0.0.1:11999/CalculoComissaoService");
   System.setProperty("cartao.visa.porta","18900");System.setProperty("cartao.master.porta","18901");
   System.setIn(new ByteArrayInputStream("talvez\nSIM\nSIM\nN\u00c3O\n".getBytes(StandardCharsets.UTF_8)));
   context=new DefaultMuleContextFactory().createMuleContext("new_tec.xml");context.start();
   System.out.println("PASS: contexto Mule iniciou com conectores reais");
   String rv=request("4234567890123456",false,200);check(rv.contains("teste-visa")&&rv.contains("7946,75")&&rv.contains("397,34"),"Resultado Visa: "+rv);check(rv.contains("STK-TESTE")&&rv.contains("BR-TESTE")&&!rv.contains("ATENCAO:"),"Codigos e total preservado");
   System.out.println("PASS: HTTP -> CEP -> frete real -> SOAP -> REST -> RMI -> confirmacao invalida/SIM -> Visa");
   String rm=request("5348345354893654",false,200);check(rm.contains("teste-master")&&rm.contains("238,40"),"Resultado Master: "+rm);
   System.out.println("PASS: Mastercard e taxa");
   int antes=pagamentos;String rn=request("4234567890123456",false,200);check(rn.contains("cancelado")&&pagamentos==antes,"Cancelar sem pagamento");
   System.out.println("PASS: NAO nao chama cartao");
   int inserts=fornecedores;String erro=request("4234567890123456",true,500);check(erro.contains("CEP deve ter oito digitos"),"Mensagem de validacao clara: "+erro);check(fornecedores==inserts,"Validacao antes de inserir");
   cepVazio=true;String semCep=request("4234567890123456",false,500);
   check(semCep.contains("Consulta de CEP sem resultado"),"Erro claro para CEP sem resultado: "+semCep);
   check(fornecedores==inserts && pagamentos==antes,"CEP sem resultado interrompe antes de fornecedores/cartao");cepVazio=false;
   System.out.println("PASS: CEP exige GET e resposta 204 interrompe com mensagem clara");
   falhar=true;request("4234567890123456",false,500);check(pagamentos==antes,"Falha fornecedor impede pagamento");
   System.out.println("PASS: falhas abortam antes do pagamento; todas as verificacoes passaram");
  } finally {
   if(context!=null){context.stop();context.dispose();}if(http!=null)http.stop(0);if(visa!=null)visa.close();if(master!=null)master.close();
   if(service!=null)UnicastRemoteObject.unexportObject(service,true);if(registry!=null)UnicastRemoteObject.unexportObject(registry,true);
  }
 }
}
