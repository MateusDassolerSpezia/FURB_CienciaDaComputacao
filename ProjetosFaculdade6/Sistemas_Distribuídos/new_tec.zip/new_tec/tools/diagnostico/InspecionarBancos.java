import java.sql.*;
public class InspecionarBancos {
 public static void main(String[] args) throws Exception {
  Class.forName("org.apache.derby.jdbc.ClientDriver");
  for(String banco:new String[]{"StarkSystem","BrRobotics"}) {
   try(Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/"+banco,"root","root")) {
    c.setReadOnly(true);
    System.out.println("BANCO "+banco+" DERBY "+c.getMetaData().getDatabaseProductVersion());
    try(ResultSet r=c.getMetaData().getColumns(null,null,"PEDIDOS",null)) {
     while(r.next()) System.out.println(r.getString("TABLE_SCHEM")+"."+r.getString("TABLE_NAME")+" "+r.getString("COLUMN_NAME")+" "+r.getString("TYPE_NAME")+" tamanho="+r.getInt("COLUMN_SIZE")+" nullable="+r.getInt("NULLABLE")+" identity="+r.getString("IS_AUTOINCREMENT")+" default="+r.getString("COLUMN_DEF"));
    }
    try(Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT COUNT(*) FROM ROOT.PEDIDOS")) {r.next();System.out.println("Registros="+r.getInt(1));}
   }
  }
 }
}