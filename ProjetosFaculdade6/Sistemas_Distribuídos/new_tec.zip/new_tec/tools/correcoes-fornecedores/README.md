# Correcao aplicada aos projetos externos com autorizacao

A inspeção de leitura confirmou em StarkSystem e BrRobotics: ROOT.PEDIDOS.CODIGO é NUMERIC(10), NOT NULL, sem IDENTITY e sem DEFAULT. Cada banco tem três registros.

Os DAOs atuais incluem CODIGO no INSERT, passam null e tentam usar getGeneratedKeys. A correção gera MAX(CODIGO)+1 dentro de uma transação com bloqueio exclusivo de tabela, insere e devolve o código. O bloqueio evita colisão entre requisições concorrentes. Não usa código enviado pelo cliente, não altera o esquema e preserva os registros existentes. O bloqueio dura somente a inserção e é adequado ao volume acadêmico; para maior escala, considerar sequência/IDENTITY com migração própria.

Arquivos preparados:
- StarkSystem/DAOPedido.java -> C:/Users/mdspezia/Documents/NetBeansProjects/StarkSystem/src/java/com/starksystem/dao/DAOPedido.java
- BrRobotics/DAOPedido.java -> C:/Users/mdspezia/Documents/NetBeansProjects/BrRobotics/src/java/com/brrobotics/dao/DAOPedido.java

Os dois arquivos foram aplicados com autorizacao e compilados com Java 8. Falta recompilar o projeto completo e fazer Deploy de ambos no NetBeans. A StarkSystem continua com seu total fixo atual; esta correção trata apenas geração de código. Nenhuma compra de teste foi inserida nos bancos reais.

O erro DomainResource pertence ao subsistema de administração REST do GlassFish. O stack trace da compra chega a DAOPedido.insert e falha na restrição SQL; a correção de CODIGO não depende de alterar a configuração administrativa do servidor.

Backup dos DAOs originais: C:\Users\mdspezia\AnypointStudio\workspace\new_tec\tools\correcoes-fornecedores\backups\20261112-101641
