package com.brrobotics.dao;

import com.brrobotics.modelo.Pedido;
import java.sql.*;

public class DAOPedido {
    private static final DAOPedido INSTANCE = new DAOPedido();
    public static DAOPedido getInstance() { return INSTANCE; }

    private Connection openConnection() throws SQLException {
        try { Class.forName("org.apache.derby.jdbc.ClientDriver"); }
        catch(ClassNotFoundException e) { throw new SQLException("Driver Derby indisponivel.", e); }
        return DriverManager.getConnection("jdbc:derby://localhost:1527/BrRobotics", "root", "root");
    }

    public Pedido insert(Pedido pedido) {
        try(Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try {
                // The current CODIGO is NUMERIC(10), not IDENTITY. Generate it on the supplier.
                // The exclusive table lock is held until commit/rollback so concurrent inserts
                // cannot select the same MAX(CODIGO). No schema changes or data deletion required.
                long codigo;
                try(Statement lock = conn.createStatement()) {
                    lock.executeUpdate("LOCK TABLE ROOT.PEDIDOS IN EXCLUSIVE MODE");
                    try(ResultSet rs = lock.executeQuery("SELECT COALESCE(MAX(CODIGO), 0) FROM ROOT.PEDIDOS")) {
                        rs.next(); codigo = Math.addExact(rs.getLong(1), 1L);
                    }
                }
                if(codigo < 1 || codigo > 9999999999L) throw new SQLException("Limite da coluna CODIGO NUMERIC(10) atingido.");

                try(PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO ROOT.PEDIDOS (CODIGO, CLIENTE, ENDERECO, ESTADO, ITENS, TOTAL) VALUES (?, ?, ?, ?, ?, ?)")) {
                    stmt.setLong(1, codigo);
                    stmt.setString(2, pedido.getCliente());
                    stmt.setString(3, pedido.getEndereco());
                    stmt.setString(4, pedido.getEstado());
                    stmt.setString(5, pedido.getItens());
                    stmt.setDouble(6, pedido.getTotal());
                    if(stmt.executeUpdate() != 1) throw new SQLException("Pedido nao foi inserido.");
                }
                conn.commit();
                pedido.setCodigo(Long.toString(codigo));
                return pedido;
            } catch(SQLException | RuntimeException e) {
                try { conn.rollback(); } catch(SQLException rollback) { e.addSuppressed(rollback); }
                throw e;
            }
        } catch(SQLException e) { throw new RuntimeException("Falha ao inserir pedido no fornecedor BrRobotics.", e); }
    }
}
