# new_tec — integração Mule 3.9.5 / Java 8

Execute somente o new_tec no Anypoint Studio; os outros exemplos Mule disputam a porta 8085. Mantenha Derby, BrRobotics, StarkSystem, comissão RMI, Visa e Mastercard em execução. Use Refresh/F5 e Project > Clean, depois Run As > Mule Application. Abra http://127.0.0.1:8085/ .

O flow principal segue: validar formulário/cartão → consultar CEP HTTPS → executar frete com UF → calcular descontos e inserir reatores SOAP → calcular descontos e inserir robôs REST → consultar comissão RMI → consolidar → confirmar no teclado → pagar → apresentar resultado. O único outro flow serve o formulário. Configurações em src/main/resources/integracao.properties; dependência RMI em lib e .classpath.

Após enviar o formulário, deixe o navegador aguardando. No console do processo Mule no Studio, confira o resumo e digite SIM ou NAO seguido de Enter. TratarResultadoPedido adapta o ConfirmarPedido.java do professor para o pacote/modelo local, preservando Scanner e confirmação síncrona. Resposta inválida pede nova entrada; NAO não paga. Console indisponível interrompe o processo.

## Regras e diferenças atuais

Descontos por tipo acima de 3 unidades: doméstico 25%, segurança 15%, médico 10%, Ark 10%, Solar 15%; depois B2B BrRobotics 15%, StarkSystem 10%. Quantidades são agregadas entre as combinações do formulário. Arredondamento em centavos por fornecedor. Sem consulta/desconto de estoque nesta etapa.

Os descontos são calculados no new_tec antes de enviar os pedidos. BrRobotics e StarkSystem gravam e retornam o total recebido. A atribuição fixa de R$ 32.000 na StarkSystem foi removida. Os códigos são gerados nos DAOs dos fornecedores, com transação e bloqueio de tabela. XML/JSON seguem o contrato local de itens/total.

A chamada RMI é obrigatória. O retorno atual de subtotal acrescido de 10% é validado; conforme escolha do usuário, a comissão local é adaptada para 15% do subtotal. Frete somado depois, sem comissão sobre ele. Se o contrato RMI mudar, revisar IntegracaoPedido.consolidar.

Taxa do cartão = valor cobrado menos valor líquido retornado. Nos serviços fornecidos: Visa 5%, Mastercard 3%. Essa taxa não é desconto para o cliente. Resumo preserva autorização, operadora, total cobrado, líquido e taxa. Os servidores aceitam nomes do cartão sem acentos, apenas letras/espaços, e validade MM/aaaa posterior ao mês atual.

Falhas retornam HTTP 500 e interrompem as próximas etapas. Não há repetição automática de pagamento. Se ocorrer falha após COMMIT, confira a operadora antes de reenviar. Pedidos já inseridos nos fornecedores continuam registrados, inclusive ao cancelar ou em falhas posteriores: as APIs não oferecem estorno. Nenhum teste automatizado deve gravar compras nos bancos reais.

Fora desta entrega: estoque/IoT, nota fiscal, persistência consolidada NewTec/S3, email e relatório. Pedido integrado permanece em memória durante a requisição. O java_policy segue o exemplo acadêmico fornecido para RMI.

## Validação

Execute `powershell -ExecutionPolicy Bypass -File new_tec/verificar.ps1` a partir do workspace. Usa o Java 8 e Mule 3.9.5 já instalados em C:/ESB (ajuste no script se necessário), inicia portas isoladas 18185, 18080, 18900, 18901 e 11999 e encerra os recursos no final. Apenas consulta WSDL/XSD da StarkSystem real em 8080 e executa o binário real de frete; todas as inserções de pedidos e transações são simuladas. Testa agregação, regras de descontos, limite de 3 unidades, comissão de 15%, fluxo HTTP completo, protocolos Visa/Mastercard, taxas, entrada inválida na confirmação, cancelamento e interrupção em falhas. Artefatos temporários e log em .verification; não usar esses overrides na execução normal.

Na verificação desta entrega, CEP/WSDL reais responderam e Derby/Visa/Mastercard estavam acessíveis. O RMI em 127.0.0.1:11099 recusou conexão; iniciar novamente BootstrapCalculoComissaoServer no Eclipse antes da execução normal. A validação completa em serviços reais continua dependendo dele e da consistência do banco dos fornecedores.

O verificador independente fica em tools/verificacao/VerificarIntegracao.java e e compilado somente pelo verificar.ps1. Ele usa com.sun.net.httpserver para simular fornecedores; por isso fica fora das pastas de fontes do Studio, cujo perfil JavaSE-1.8 restringe essa API do JDK.

A interface em src/main/app/docroot/index.html usa o CSS local estilo.css, sem JavaScript. Produtos, nomes dos campos, restrições existentes, opções de bandeira e POST /tratarForm foram preservados. Para ativar a correção do total, executar Clean and Build e Deploy de StarkSystem no NetBeans. Os pedidos antigos não são recalculados.
