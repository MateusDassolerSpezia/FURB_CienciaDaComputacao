package br.furb.dsc;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

public class Pedido implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codigo;
	private String cliente;
	private String endereco;
	private String estado;

	private String cep;

	private int qRoboDomestico;
	private int qRoboSeguranca;
	private int qRoboMedico;
	private int qReatorArk;
	private int qReatorSolar;

	private Collection<PedidoPeca> pecas = new ArrayList<>();

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public int getqRoboDomestico() {
		return qRoboDomestico;
	}

	public void setqRoboDomestico(int qRoboDomestico) {
		this.qRoboDomestico = qRoboDomestico;
	}

	public int getqRoboSeguranca() {
		return qRoboSeguranca;
	}

	public void setqRoboSeguranca(int qRoboSeguranca) {
		this.qRoboSeguranca = qRoboSeguranca;
	}

	public int getqRoboMedico() {
		return qRoboMedico;
	}

	public void setqRoboMedico(int qRoboMedico) {
		this.qRoboMedico = qRoboMedico;
	}

	public int getqReatorArk() {
		return qReatorArk;
	}

	public void setqReatorArk(int qReatorArk) {
		this.qReatorArk = qReatorArk;
	}

	public int getqReatorSolar() {
		return qReatorSolar;
	}

	public void setqReatorSolar(int qReatorSolar) {
		this.qReatorSolar = qReatorSolar;
	}

	public Collection<PedidoPeca> getPecas() {
		return pecas;
	}

	public void setPecas(Collection<PedidoPeca> pecas) {
		this.pecas = pecas;
	}

    private String bairro;
    public String getBairro() { return bairro; }
    public void setBairro(String value) { bairro = value; }

    private String cidade;
    public String getCidade() { return cidade; }
    public void setCidade(String value) { cidade = value; }

    private String nomeCartao;
    public String getNomeCartao() { return nomeCartao; }
    public void setNomeCartao(String value) { nomeCartao = value; }

    private String numeroCartao;
    public String getNumeroCartao() { return numeroCartao; }
    public void setNumeroCartao(String value) { numeroCartao = value; }

    private String dataVencimento;
    public String getDataVencimento() { return dataVencimento; }
    public void setDataVencimento(String value) { dataVencimento = value; }

    private String bandeira;
    public String getBandeira() { return bandeira; }
    public void setBandeira(String value) { bandeira = value; }

    private String confirmaPedido;
    public String getConfirmaPedido() { return confirmaPedido; }
    public void setConfirmaPedido(String value) { confirmaPedido = value; }

    private String autorizacao;
    public String getAutorizacao() { return autorizacao; }
    public void setAutorizacao(String value) { autorizacao = value; }

    private double subtotal;
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double value) { subtotal = value; }

    private double comissao;
    public double getComissao() { return comissao; }
    public void setComissao(double value) { comissao = value; }

    private double frete;
    public double getFrete() { return frete; }
    public void setFrete(double value) { frete = value; }

    private double total;
    public double getTotal() { return total; }
    public void setTotal(double value) { total = value; }

    private double valorRecebido;
    public double getValorRecebido() { return valorRecebido; }
    public void setValorRecebido(double value) { valorRecebido = value; }

    private double taxaCartao;
    public double getTaxaCartao() { return taxaCartao; }
    public void setTaxaCartao(double value) { taxaCartao = value; }

	@Override
	public String toString() {
		return "PedidoBean [codigo=" + codigo + ", cliente=" + cliente + ", endereco=" + endereco + ", estado=" + estado + ", qRoboDomestico="
				+ qRoboDomestico + ", qRoboSeguranca=" + qRoboSeguranca + ", qRoboMedico=" + qRoboMedico + ", qReatorArk=" + qReatorArk
				+ ", qReatorSolar=" + qReatorSolar + "]";
	}

}
