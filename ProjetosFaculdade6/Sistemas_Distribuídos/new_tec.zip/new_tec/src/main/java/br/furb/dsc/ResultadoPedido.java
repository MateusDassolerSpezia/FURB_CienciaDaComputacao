package br.furb.dsc;
import java.util.Locale;
public class ResultadoPedido {
    private String dinheiro(double n) { return String.format(new Locale("pt","BR"),"R$ %.2f",n); }
    public String erro(Throwable falha) {
        Throwable causa=falha;
        for(int i=0;i<20 && causa.getCause()!=null && causa.getCause()!=causa;i++) causa=causa.getCause();
        String mensagem=causa.getMessage();
        if(mensagem==null||mensagem.trim().isEmpty()) mensagem=causa.getClass().getSimpleName();
        return "Nao foi possivel concluir o pedido. "+mensagem+
            "\nPedidos ja gravados nos fornecedores permanecem registrados. Se houve COMMIT no cartao, confira a operadora antes de reenviar.";
    }
    public String apresentar(Pedido p) {
        StringBuilder s=new StringBuilder();
        s.append(p.getAutorizacao()!=null?"Compra concluida":"NAO".equals(p.getConfirmaPedido())?"Pedido cancelado - pagamento nao realizado":"Resumo para confirmacao");
        s.append("\nCliente: ").append(p.getCliente()).append("\nCEP: ").append(p.getCep());
        s.append("\nEndereco: ").append(p.getEndereco()).append("\nBairro: ").append(p.getBairro());
        s.append("\nCidade/UF: ").append(p.getCidade()).append(" / ").append(p.getEstado()).append("\n");
        for(PedidoPeca r:p.getPecas()) {
            s.append("\n").append(r instanceof PedidoRobo?"BrRobotics":"StarkSystem").append(" - codigo: ").append(r.getCodigo());
            s.append("\nItens: ").append(r.getItens()).append("\nValor bruto: ").append(dinheiro(r.getTotalBruto()));
            s.append("\nDescontos por quantidade e B2B: ").append(dinheiro(r.getDesconto()));
            s.append("\nValor calculado para repasse: ").append(dinheiro(r.getTotal())).append("\n");
            if(Math.abs(r.getTotalRetornado()-r.getTotal())>.01)
                s.append("ATENCAO: fornecedor retornou/gravou ").append(dinheiro(r.getTotalRetornado())).append("; diverge do valor calculado acima.\n");
        }
        s.append("\nSubtotal dos fornecedores: ").append(dinheiro(p.getSubtotal()));
        s.append("\nComissao NewTec (15%): ").append(dinheiro(p.getComissao()));
        s.append("\nFrete: ").append(dinheiro(p.getFrete())).append("\nTotal do cliente: ").append(dinheiro(p.getTotal()));
        s.append("\nOperadora: ").append(p.getBandeira());
        if(p.getAutorizacao()!=null) {
            s.append("\nTransacao: ").append(p.getAutorizacao());
            s.append("\nTaxa da operadora: ").append(dinheiro(p.getTaxaCartao()));
            s.append("\nValor recebido pela NewTec: ").append(dinheiro(p.getValorRecebido()));
        }
        if("NAO".equals(p.getConfirmaPedido())) s.append("\nOs pedidos ja inseridos nos fornecedores permanecem registrados; os servicos nao oferecem cancelamento.");
        return s.toString();
    }
}
