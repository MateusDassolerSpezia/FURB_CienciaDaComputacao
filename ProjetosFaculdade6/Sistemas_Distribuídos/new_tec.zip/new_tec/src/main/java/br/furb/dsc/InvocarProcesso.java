package br.furb.dsc;
import java.io.*;
import java.util.concurrent.TimeUnit;
public class InvocarProcesso {
    private String executavel;
    public void setExecutavel(String value) { executavel=value; }
    public Pedido calcularFrete(Pedido pedido) throws Exception {
        if(!new File(executavel).isFile()) throw new IOException("Executavel de frete nao encontrado: "+executavel);
        Process processo=new ProcessBuilder(executavel,pedido.getEstado()).redirectErrorStream(true).start();
        try {
            if(!processo.waitFor(10,TimeUnit.SECONDS)) throw new IOException("Tempo limite no calculo do frete.");
            StringBuilder out=new StringBuilder();
            try(BufferedReader r=new BufferedReader(new InputStreamReader(processo.getInputStream()))) {
                String line; while((line=r.readLine())!=null) out.append(line);
            }
            if(processo.exitValue()!=0) throw new IOException("Falha no executavel de frete.");
            double frete=Double.parseDouble(out.toString().trim());
            if(frete<0) throw new IOException("UF recusada pelo calculo do frete.");
            pedido.setFrete(IntegracaoPedido.moeda(frete)); return pedido;
        } finally { processo.destroy(); }
    }
}
