package br.furb.dsc;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
public class PagamentoPedido {
    private String host="127.0.0.1";
    private int portaVisa=8900,portaMaster=8901;
    public void setHost(String v) { host=v; }
    public void setPortaVisa(int v) { portaVisa=v; }
    public void setPortaMaster(int v) { portaMaster=v; }
    public Pedido processar(Pedido p) throws IOException {
        if(!"SIM".equals(p.getConfirmaPedido())) throw new IllegalStateException("Pagamento exige confirmacao explicita.");
        boolean visa="VISA".equals(p.getBandeira());
        if(!visa&&!"MASTERCARD".equals(p.getBandeira())) throw new IllegalArgumentException("Bandeira invalida.");
        boolean commitEnviado=false;
        try(Socket s=new Socket()) {
            s.connect(new InetSocketAddress(host,visa?portaVisa:portaMaster),5000); s.setSoTimeout(10000);
            BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));
            BufferedWriter out=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8));
            String hello=ler(in);
            if(!(visa?"Visa Payment Service":"Mastercard Payment Service").equals(hello)) throw new IOException("Saudacao inesperada da operadora.");
            enviar(out,in,visa?"PAY":"PAYMENT","OK");
            if(visa) enviar(out,in,p.getNumeroCartao(),"OK");
            else for(int i=0;i<16;i+=4) enviar(out,in,p.getNumeroCartao().substring(i,i+4),"PROCEED");
            String ack=visa?"OK":"PROCEED";
            enviar(out,in,p.getNomeCartao(),ack); enviar(out,in,p.getDataVencimento(),ack);
            enviar(out,in,String.format(Locale.US,"%.2f",p.getTotal()),ack);
            commitEnviado=true;
            enviar(out,in,"COMMIT","OK");
            String[] partes=ler(in).split(":",-1);
            if(partes.length!=(visa?6:4)||partes[0].isEmpty()) throw new IOException("Resposta de transacao invalida.");
            p.setAutorizacao(partes[0]);
            double cobrado=Double.parseDouble(partes[visa?4:2]);
            double recebido=Double.parseDouble(partes[visa?5:3]);
            if(!Double.isFinite(cobrado)||!Double.isFinite(recebido)||Math.abs(cobrado-p.getTotal())>.01||recebido<0||recebido>cobrado) throw new IOException("Valores invalidos retornados pela operadora.");
            p.setValorRecebido(IntegracaoPedido.moeda(recebido));
            p.setTaxaCartao(IntegracaoPedido.moeda(cobrado-recebido)); return p;
        } catch(Exception e) {
            throw new IOException((commitEnviado?"Pagamento com resultado incerto apos COMMIT; confira a operadora antes de reenviar. ":"Pagamento nao concluido. ")+e.getMessage(),e);
        } finally { p.setNumeroCartao(null); p.setNomeCartao(null); p.setDataVencimento(null); }
    }
    private String ler(BufferedReader in) throws IOException {
        String v=in.readLine();
        if(v==null) throw new EOFException("Operadora encerrou a conexao.");
        if(v.startsWith("ERROR")) throw new IOException("Operadora recusou a requisicao: "+v);
        return v;
    }
    private void enviar(BufferedWriter out,BufferedReader in,String msg,String esperado) throws IOException {
        out.write(msg); out.newLine(); out.flush();
        if(!esperado.equals(ler(in))) throw new IOException("Resposta inesperada da operadora.");
    }
}
