package br.furb.dsc;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.io.StringReader;
import java.util.Map;
import javax.xml.parsers.DocumentBuilderFactory;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.codehaus.jackson.map.ObjectMapper;
public class IntegracaoPedido {
    public static double moeda(double n) {
        if(!Double.isFinite(n)||n<0) throw new IllegalArgumentException("Valor monetario invalido.");
        return BigDecimal.valueOf(n).setScale(2,RoundingMode.HALF_UP).doubleValue();
    }
    public Pedido atualizarCep(Pedido p, String json) throws Exception {
        if(json==null || json.trim().isEmpty())
            throw new IllegalArgumentException("Consulta de CEP sem resultado para "+p.getCep()+". Verifique o CEP informado; a consulta deve usar GET.");
        Map<?,?> dados=new ObjectMapper().readValue(json,Map.class);
        if(dados==null) throw new IllegalArgumentException("Consulta de CEP retornou endereco nulo.");
        String uf=campo(dados,"uf");
        if(!uf.matches("AC|AL|AP|AM|BA|CE|DF|ES|GO|MA|MT|MS|MG|PA|PB|PR|PE|PI|RJ|RN|RS|RO|RR|SC|SP|SE|TO")) throw new IllegalArgumentException("CEP sem UF valida.");
        p.setEstado(uf); p.setEndereco(campo(dados,"logradouro"));
        p.setBairro(campo(dados,"bairro")); p.setCidade(campo(dados,"localidade"));
        return p;
    }
    private String campo(Map<?,?> m,String k) {
        Object v=m.get(k); if(v==null||v.toString().trim().isEmpty()) throw new IllegalArgumentException("Consulta de CEP sem "+k+".");
        return v.toString();
    }
    public PedidoReator prepararReator(Pedido p) {
        PedidoReator r=new TratarPedidoReator().tratarPedido(p);
        r.setTotalBruto(moeda(p.getqReatorArk()*2500.0+p.getqReatorSolar()*1500.0));
        r.setTotal(moeda((item(p.getqReatorArk(),2500,.10)+item(p.getqReatorSolar(),1500,.15))*.90));
        p.getPecas().add(r); return r;
    }
    public PedidoRobo prepararRobo(Pedido p) {
        PedidoRobo r=new TratarPedidoRobo().tratarPedido(p);
        r.setTotalBruto(moeda(p.getqRoboDomestico()*900.0+p.getqRoboSeguranca()*1800.0+p.getqRoboMedico()*2500.0));
        r.setTotal(moeda((item(p.getqRoboDomestico(),900,.25)+item(p.getqRoboSeguranca(),1800,.15)+item(p.getqRoboMedico(),2500,.10))*.85));
        p.getPecas().add(r); return r;
    }
    private double item(int q,double valor,double desconto) { return q*valor*(q>3?1-desconto:1); }
    public Pedido receberReator(Pedido p,Object resposta) throws Exception {
        if(resposta instanceof javax.xml.stream.XMLStreamReader) {
            javax.xml.stream.XMLStreamReader reader=(javax.xml.stream.XMLStreamReader)resposta;
            String codigo=null,total=null;
            try {
                while(true) {
                    if(reader.isStartElement()) {
                        if("codigo".equals(reader.getLocalName())) codigo=reader.getElementText();
                        else if("total".equals(reader.getLocalName())) total=reader.getElementText();
                    }
                    if(codigo!=null && total!=null) break;
                    if(!reader.hasNext()) break;
                    reader.next();
                }
            } finally { reader.close(); }
            if(codigo==null||total==null) throw new IllegalArgumentException("Resposta StarkSystem sem codigo/total.");
            registrar(p,PedidoReator.class,codigo,total);return p;
        }
        String xml=resposta.toString();
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance(); f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        Document d=f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
        registrar(p,PedidoReator.class,texto(d,"codigo"),texto(d,"total")); return p;
    }
    private String texto(Document d,String tag) {
        if(d.getElementsByTagNameNS("*",tag).getLength()==0) throw new IllegalArgumentException("Resposta StarkSystem sem "+tag);
        return d.getElementsByTagNameNS("*",tag).item(0).getTextContent();
    }
    public Pedido receberRobo(Pedido p,String json) throws Exception {
        if(json==null || json.trim().isEmpty()) throw new IllegalArgumentException("BrRobotics retornou resposta vazia ao inserir o pedido.");
        Map<?,?> m=new ObjectMapper().readValue(json,Map.class);
        if(m==null) throw new IllegalArgumentException("BrRobotics nao retornou os dados do pedido.");
        registrar(p,PedidoRobo.class,campo(m,"codigo"),campo(m,"total")); return p;
    }
    private void registrar(Pedido p,Class<?> tipo,String codigo,String valor) {
        if(codigo==null||codigo.trim().isEmpty()||"null".equals(codigo)) throw new IllegalArgumentException("Fornecedor nao retornou codigo do pedido.");
        for(PedidoPeca r:p.getPecas()) if(tipo.isInstance(r)) { r.setCodigo(codigo); r.setTotalRetornado(moeda(Double.parseDouble(valor))); return; }
        throw new IllegalStateException("Pedido do fornecedor nao preparado.");
    }
    public Float subtotal(Pedido p) {
        double total=0; for(PedidoPeca r:p.getPecas()) total+=r.getTotal();
        p.setSubtotal(moeda(total)); return (float)p.getSubtotal();
    }
    public Pedido consolidar(Pedido p,Number retornoRmi) {
        double valor=retornoRmi.doubleValue();
        // The supplied RMI service adds 10%. Validate it, then adapt to the required 15% locally.
        float esperado=(float)(((float)p.getSubtotal())*1.10);
        if(!Double.isFinite(valor)||Math.abs(valor-esperado)>Math.max(.01,Math.ulp(esperado))) throw new IllegalStateException("Retorno RMI diverge do contrato atual de 10%.");
        p.setComissao(moeda(p.getSubtotal()*.15));
        p.setTotal(moeda(p.getSubtotal()+p.getComissao()+p.getFrete())); return p;
    }
}
