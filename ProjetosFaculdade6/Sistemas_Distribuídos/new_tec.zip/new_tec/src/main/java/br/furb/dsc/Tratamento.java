package br.furb.dsc;
import java.util.Map;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
public class Tratamento {
    public Pedido tratarDados(Map<String,String> params) {
        Pedido p = new Pedido();
        p.setCliente(obrigatorio(params,"nome"));
        String cep = obrigatorio(params,"cep").replaceAll("[- ]", "");
        if (!cep.matches("[0-9]{8}")) throw new IllegalArgumentException("CEP deve ter oito digitos.");
        p.setCep(cep);
        int da=q(params,"QRDRA"), ds=q(params,"QRDRS"), sa=q(params,"QRSRA"), ss=q(params,"QRSRS"), ma=q(params,"QRMRA"), ms=q(params,"QRMRS");
        if (da+ds+sa+ss+ma+ms==0) throw new IllegalArgumentException("Selecione ao menos um produto.");
        p.setqRoboDomestico(da+ds); p.setqRoboSeguranca(sa+ss); p.setqRoboMedico(ma+ms);
        p.setqReatorArk(da+sa+ma); p.setqReatorSolar(ds+ss+ms);
        p.setNomeCartao(obrigatorio(params,"nomeCartao"));
        if (!p.getNomeCartao().matches("[A-Za-z]+(?: [A-Za-z]+)*")) throw new IllegalArgumentException("O servico do cartao aceita nome sem acentos, apenas letras e espacos.");
        String numero=obrigatorio(params,"numeroCartao").replaceAll("[- ]", "");
        if (!numero.matches("[0-9]{16}")) throw new IllegalArgumentException("Cartao deve ter 16 digitos.");
        p.setNumeroCartao(numero);
        String bandeira=obrigatorio(params,"bandeira");
        if (!("VISA".equals(bandeira) && numero.startsWith("4")) && !("MASTERCARD".equals(bandeira) && numero.matches("5[1-5][0-9]{14}")))
            throw new IllegalArgumentException("Numero incompativel com a bandeira selecionada.");
        p.setBandeira(bandeira);
        String validade=params.get("dataVencimento");
        if (validade==null) validade=params.get("validadeCartao");
        try {
            YearMonth data=YearMonth.parse(validade,DateTimeFormatter.ofPattern("MM/uuuu").withResolverStyle(ResolverStyle.STRICT));
            // The supplied services compare with the first day of the month.
            if (!data.isAfter(YearMonth.now())) throw new IllegalArgumentException();
        } catch (Exception e) { throw new IllegalArgumentException("Validade deve ser MM/aaaa, posterior ao mes atual."); }
        p.setDataVencimento(validade);
        return p;
    }
    private int q(Map<String,String> m,String key) {
        String v=m.get(key);
        if(v==null||v.trim().isEmpty()) return 0;
        try { int n=Integer.parseInt(v); if(n<0||n>1000) throw new NumberFormatException(); return n; }
        catch(NumberFormatException e) { throw new IllegalArgumentException("Quantidade invalida: "+key+" (0 a 1000)."); }
    }
    private String obrigatorio(Map<String,String> m,String k) {
        String v=m.get(k);
        if(v==null||v.trim().isEmpty()) throw new IllegalArgumentException("Campo obrigatorio: "+k);
        return v.trim();
    }
}
