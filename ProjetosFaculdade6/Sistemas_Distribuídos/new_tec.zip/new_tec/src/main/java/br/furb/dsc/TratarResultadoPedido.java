package br.furb.dsc;
import java.util.Scanner;
public class TratarResultadoPedido {
    // Adapted from the professor's ConfirmarPedido.java: synchronous keyboard confirmation.
    // One shared scanner/lock prevents concurrent requests from consuming each other's answer.
    private static final Scanner SC = new Scanner(System.in,"UTF-8");
    public Pedido tratarResultadoPedido(Pedido pedido) {
        synchronized(SC) {
            System.out.println(new ResultadoPedido().apresentar(pedido));
            while(true) {
                System.out.println("Finalizar o pedido? [SIM ou NAO]");
                if(!SC.hasNextLine()) throw new IllegalStateException("Console indisponivel para confirmar o pedido.");
                String resp=SC.nextLine().trim();
                if("SIM".equalsIgnoreCase(resp)) { pedido.setConfirmaPedido("SIM"); return pedido; }
                if("NAO".equalsIgnoreCase(resp)||"N\u00c3O".equalsIgnoreCase(resp)) { pedido.setConfirmaPedido("NAO"); return pedido; }
                System.out.println("Resposta invalida. Digite SIM ou NAO.");
            }
        }
    }
}
