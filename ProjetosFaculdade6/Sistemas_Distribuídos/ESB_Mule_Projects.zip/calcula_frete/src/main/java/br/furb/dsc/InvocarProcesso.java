package br.furb.dsc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InvocarProcesso {

	public String invocarProcesso(String cmd) {

		StringBuilder sb = new StringBuilder();

		try {

			// Invocando o processo com comando na variavel 'cmd'
			Process p = Runtime.getRuntime().exec(cmd);

			// Obtendo o stream de retorno
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {

				String line;

				while ((line = reader.readLine()) != null) {
					sb.append(line + "\n");
				}
			}

			// Esperando o processo finalizar...
			p.waitFor();

			return sb.toString();

		} catch (IOException | InterruptedException e) {
			return "Erro executando comando '" + cmd + "'. Erro: " + e.getMessage();
		}
	}

}
