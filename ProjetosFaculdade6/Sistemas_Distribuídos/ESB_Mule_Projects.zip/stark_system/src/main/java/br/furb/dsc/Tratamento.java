package br.furb.dsc;

import java.util.Map;

public class Tratamento {

	public Pedido tratarRequisicao(Map<String, String> params) {

		Pedido pedido = new Pedido();

		String quantidadeReatorArk = params.get("QRA");
		int quantidadereatorark = Integer.parseInt(quantidadeReatorArk);
		
		String quantidadeReatorSolar = params.get("QRS");
		int quantidadereatorsolar = Integer.parseInt(quantidadeReatorSolar);
		
		String itens = quantidadeReatorArk + "-Reator ARk " + quantidadeReatorSolar + "-Reator Solar";
		String qtdReatorArk = quantidadeReatorArk;
		String qtdReatorSolar = quantidadeReatorSolar;
		
		String codigoCliente = params.get("codigo");
		int codigo = Integer.parseInt(codigoCliente);
		
			
		String nome = params.get("nome");
		String endereco = params.get("endereco");
		String estado = params.get("estado");
		
		
		pedido.setCodigo(codigo);
		pedido.setCliente(nome);
		pedido.setEndereco(endereco);
		pedido.setEstado(estado);
		pedido.setItens(itens);
		pedido.setQtdReatorArk(quantidadereatorark);
		pedido.setQtdReatorSolar(quantidadereatorsolar);
		

			
		int qReatorArk = quantidadereatorark;
		int qReatorSolar = quantidadereatorsolar;
/*
	//	int qRA = Integer.parseInt(quantidadeReatorArk);

		int qRS = Integer.parseInt(quantidadeReatorSolar);

	//	if (qRA > 0) {
		//	qReatorArk = qRA;
		//}

		if (qRS > 0) {
			qReatorSolar = qRS;
		}

		// preencher beans com os itens

		pedido.setQtdReatorArk(qReatorArk);
		pedido.setQtdReatorSolar(qReatorSolar);
*/		
		pedido.setTotal(quantidadereatorark * 2000 + quantidadereatorsolar * 1000);
		
	

		return pedido;
	}
}
