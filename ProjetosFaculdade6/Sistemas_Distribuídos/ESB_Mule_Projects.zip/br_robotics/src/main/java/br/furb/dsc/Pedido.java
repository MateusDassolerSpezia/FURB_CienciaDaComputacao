package br.furb.dsc;

import java.io.Serializable;

public class Pedido implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer codigo;
	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getItens() {
		return itens;
	}

	public void setItens(String itens) {
		this.itens = itens;
	}

	public int getQtdRoboSeguranca() {
		return qtdRoboSeguranca;
	}

	public void setQtdRoboSeguranca(int qtdRoboSeguranca) {
		this.qtdRoboSeguranca = qtdRoboSeguranca;
	}

	public int getQtdRoboDomestico() {
		return qtdRoboDomestico;
	}

	public void setQtdRoboDomestico(int qtdRoboDomestico) {
		this.qtdRoboDomestico = qtdRoboDomestico;
	}

	public int getQtdRoboMedico() {
		return qtdRoboMedico;
	}

	public void setQtdRoboMedico(int qtdRoboMedico) {
		this.qtdRoboMedico = qtdRoboMedico;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String cliente;
	private String endereco;
	private String estado;
	private String itens;
	private int qtdRoboSeguranca;
	private int qtdRoboDomestico;
	private int qtdRoboMedico;
	private double total;
	


	// Feito pq provavelmente o Mule tem um "bug" que somente aceitar setters do
	// tipo string
	public void setTotal(String total) {
		this.total = Double.parseDouble(total);
	}

	@Override
	public String toString() {
		return "Pedido [codigo=" + codigo + ", cliente=" + cliente
				+ ", endereco=" + endereco + ", estado=" + estado + ", itens=" + itens
				+  ", total=" + total + "]";
	}

}
