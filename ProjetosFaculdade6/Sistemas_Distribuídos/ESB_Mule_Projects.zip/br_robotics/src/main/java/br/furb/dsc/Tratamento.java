package br.furb.dsc;

import java.util.Map;

public class Tratamento {

	public Pedido tratarRequisicao(Map<String, String> params) {

		Pedido pedido = new Pedido();

		String quantidadeRoboSeguranca = params.get("QRS");
		int quantidaderoboseguranca = Integer.parseInt(quantidadeRoboSeguranca);
		
		String quantidadeRoboDomestico = params.get("QRD");
		int quantidaderobodomestico = Integer.parseInt(quantidadeRoboDomestico);
		
		String quantidadeRoboMedico = params.get("QRM");
		int quantidaderobomedico = Integer.parseInt(quantidadeRoboMedico);
		
			
		String itens = quantidadeRoboSeguranca + "-Robo Segurança " + 
				quantidadeRoboDomestico + "-Robo Doméstico " + 
				quantidadeRoboMedico + "-Robo Médico";
		
		//String qtdRoboSeguranca = quantidadeRoboSeguranca;
		//String qtdRoboDomestico = quantidadeRoboDomestico;
		//String qtdRoboMedico = quantidadeRoboMedico;
		
		String codigoCliente = params.get("codigo");
		int codigo = Integer.parseInt(codigoCliente);
		
			
		String nome = params.get("nome");
		String endereco = params.get("endereco");
		String estado = params.get("estado");
		
		
		pedido.setCodigo(codigo);
		pedido.setCliente(nome);
		pedido.setEndereco(endereco);
		pedido.setEstado(estado);
		pedido.setItens(itens);
		//pedido.setQtdRoboSeguranca(quantidaderoboseguranca);
		//pedido.setQtdRoboDomestico(quantidaderobodomestico);
		//pedido.setQtdRoboMedico(quantidaderobomedico);
		
		
		
		//int qRoboSeguranca = quantidaderoboseguranca;
		//int qRoboDomestico = quantidaderobodomestico;
		//int qRoboMedico = quantidaderobomedico;
	

		pedido.setTotal(quantidaderoboseguranca * 1500 + 
				quantidaderobodomestico * 800 + quantidaderobomedico * 2000 );
		
		
		
	

		return pedido;
	}
}


