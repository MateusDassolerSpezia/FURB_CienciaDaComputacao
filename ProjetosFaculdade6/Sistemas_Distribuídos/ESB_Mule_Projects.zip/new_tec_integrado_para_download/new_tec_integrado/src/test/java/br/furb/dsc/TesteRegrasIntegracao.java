package br.furb.dsc;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/** Rode como classe Java (sem JUnit): verifica precos e controle de confirmacao. */
public class TesteRegrasIntegracao {
    public static void main(String[] args) throws Exception {
        PedidoIntegrado p=new PedidoIntegrado();
        p.domestico=4; p.solar=4;
        new CalcularDescontos().calcular(p);
        confere(new BigDecimal("2295.00"),p.brTotal,"desconto robo 4 un");
        confere(new BigDecimal("4590.00"),p.starkTotal,"desconto solar 4 un");
        p.domestico=3; p.solar=3;
        new CalcularDescontos().calcular(p);
        confere(new BigDecimal("2295.00"),p.brTotal,"robos 3 un: apenas B2B");
        confere(new BigDecimal("4050.00"),p.starkTotal,"reatores 3 un: apenas B2B");
        p.domestico=4; p.solar=4;p.descontoEstoqueBr=1;p.descontoEstoqueStark=0;
        new CalcularDescontos().calcular(p);
        confere(new BigDecimal("2180.25"),p.brTotal,"estoque adicional Br 5%");
        confere(new BigDecimal("4590.00"),p.starkTotal,"estoque Stark sem desconto");
        if(!ConfirmarPedido.respostaValida("SIM") || ConfirmarPedido.respostaValida("NAO"))throw new AssertionError("Confirmacao SIM/NAO");
        if(!JsonPlano.texto(JsonPlano.ler("{\"uf\":\"SC\",\"codigo\":4}"),"uf").equals("SC"))throw new AssertionError("JSON CEP");
        PedidoIntegrado semConfirmar=new PedidoIntegrado();
        try {new ProcessarPagamento().realizar(semConfirmar);throw new AssertionError("Cobranca sem confirmar");}
        catch(SecurityException esperado) { }
        System.out.println("Todos os testes locais de regras passaram");
    }
    private static void confere(BigDecimal esperado,BigDecimal atual,String contexto){
        if(esperado.compareTo(atual)!=0)throw new AssertionError(contexto+": esperado "+esperado+" mas retornou "+atual);
    }
}
