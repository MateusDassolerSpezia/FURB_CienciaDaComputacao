package br.furb.dsc;

import java.util.Map;
import java.util.regex.Pattern;

/** Entrada do formulario original NewTec, consolidacao de seis kits de pecas. */
public class ReceberPedido {
    public PedidoIntegrado receber(Map<String, String> params) {
        if(params==null)throw new IllegalArgumentException("Formulario ausente");
        PedidoIntegrado p = new PedidoIntegrado();
        p.cliente = obrigatorio(params,"nome",2,40);
        p.email = opcional(params,"email",100);
        p.cep = obrigatorio(params,"cep",8,9).replace("-","");
        if(!p.cep.matches("[0-9]{8}")) throw new IllegalArgumentException("CEP deve conter 8 digitos");
        p.complemento = opcional(params,"numeroEndereco",50);
        int dArk = qtd(params,"QRDRA"), dSol=qtd(params,"QRDRS");
        int sArk = qtd(params,"QRSRA"), sSol=qtd(params,"QRSRS");
        int mArk = qtd(params,"QRMRA"), mSol=qtd(params,"QRMRS");
        p.domestico=dArk+dSol; p.seguranca=sArk+sSol; p.medico=mArk+mSol;
        p.ark=dArk+sArk+mArk; p.solar=dSol+sSol+mSol;
        if(p.domestico+p.seguranca+p.medico<1) throw new IllegalArgumentException("Escolha pelo menos um conjunto de robo e reator");
        p.produtos.put("Robo domestico + reator Ark",dArk);
        p.produtos.put("Robo domestico + reator solar",dSol);
        p.produtos.put("Robo seguranca + reator Ark",sArk);
        p.produtos.put("Robo seguranca + reator solar",sSol);
        p.produtos.put("Robo medico + reator Ark",mArk);
        p.produtos.put("Robo medico + reator solar",mSol);
        p.bandeira=obrigatorio(params,"bandeira",4,10).toLowerCase();
        if(!p.bandeira.equals("visa")&&!p.bandeira.equals("mastercard"))throw new IllegalArgumentException("Bandeira invalida");
        p.nomeCartao=obrigatorio(params,"nomeCartao",2,80);
        p.numeroCartao=obrigatorio(params,"numeroCartao",16,16);
        if(!Pattern.matches("\\d{16}",p.numeroCartao))throw new IllegalArgumentException("Cartao deve ter 16 digitos");
        if (p.bandeira.equals("visa") && !p.numeroCartao.startsWith("4")) throw new IllegalArgumentException("Visa deve comecar com 4");
        if (p.bandeira.equals("mastercard") && !p.numeroCartao.substring(0,2).matches("5[1-5]")) throw new IllegalArgumentException("Mastercard deve comecar com 51 a 55");
        p.cartaoFinal=p.numeroCartao.substring(12);
        p.validadeCartao=obrigatorio(params,"dataVencimento",7,7);
        if(!p.validadeCartao.matches("(0[1-9]|1[0-2])/[0-9]{4}"))throw new IllegalArgumentException("Data de vencimento invalida; use MM/AAAA");
        return p;
    }
    private static String obrigatorio(Map<String,String> p,String k,int min,int max) {
        String x=opcional(p,k,max);
        if(x.length()<min)throw new IllegalArgumentException("Campo obrigatorio/invalido: "+k);
        return x;
    }
    private static String opcional(Map<String,String> p,String k,int max) {
        String x=p.get(k);x=x==null?"":x.trim();
        if(x.length()>max) throw new IllegalArgumentException("Campo muito longo: "+k);
        return x;
    }
    private static int qtd(Map<String,String> p,String k) {
        String x=p.get(k); if(x==null||x.trim().isEmpty())return 0;
        if(!x.matches("\\d{1,3}"))throw new IllegalArgumentException("Quantidade invalida: "+k);
        return Integer.parseInt(x);
    }
}
