package br.furb.dsc;

import java.math.BigDecimal;
import java.util.Map;

public final class HtmlPedido {
    private HtmlPedido() { }
    static String esc(String v){return v==null?"":v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    static String reais(BigDecimal v){return "R$ " + (v==null?"0.00":v.setScale(2,BigDecimal.ROUND_HALF_UP).toPlainString()).replace('.',',');}
    static String inicio(String titulo){return "<!doctype html><html lang='pt-BR'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>"+esc(titulo)+"</title>"+
            "<style>body{font:16px Arial,sans-serif;background:#f5f8fc;color:#17283a;max-width:790px;margin:40px auto;padding:0 15px}main{background:white;padding:26px;border-radius:11px;box-shadow:0 2px 8px #dde6ef}h1{color:#195a9b}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #e4e7ec;text-align:left}th{background:#f2f6fb}.total{font-weight:bold;font-size:1.25rem}.warn{background:#fff4d7;padding:10px;border-radius:6px}.sim{background:#207445;color:white}.nao{background:#a43b34;color:white}button,a.botao{border:none;border-radius:6px;padding:13px 22px;display:inline-block;text-decoration:none;cursor:pointer;margin-right:10px}a.botao{background:#2768a1;color:white}</style></head><body><main><h1>"+esc(titulo)+"</h1>";}
    static String fim(){return "<p><a class='botao' href='/'>Nova compra</a></p></main></body></html>";}
    static String tabela(PedidoIntegrado p){
        StringBuilder b=new StringBuilder("<p><strong>Cliente:</strong> "+esc(p.cliente)+"</p><p><strong>Entrega:</strong> "+esc(p.endereco)+", "+esc(p.bairro)+", "+esc(p.cidade)+" - "+esc(p.uf)+" (CEP "+esc(p.cep)+")</p>");
        b.append("<table><tr><th>Descricao</th><th>Valor</th></tr>");
        for(Map.Entry<String,Integer> i:p.produtos.entrySet())if(i.getValue()>0)b.append("<tr><td>").append(esc(i.getKey())).append(" × ").append(i.getValue()).append("</td><td>Incluido abaixo</td></tr>");
        linha(b,"BrRobotics (pedido "+p.codigoBr+")",reais(p.brTotal));
        linha(b,"StarkSystem (pedido "+p.codigoStark+")",reais(p.starkTotal));
        linha(b,"Desconto estoque BrRobotics",!p.estoqueConsultado?"Nao consultado (etapa futura)":p.descontoEstoqueBr==1?"5% aplicado":"0%");
        linha(b,"Desconto estoque StarkSystem",!p.estoqueConsultado?"Nao consultado (etapa futura)":p.descontoEstoqueStark==1?"5% aplicado":"0%");
        linha(b,"Comissao NewTec (RMI)",reais(p.comissao));
        linha(b,"Frete (executavel legado)",reais(p.frete));
        b.append("<tr class='total'><td>Total a pagar</td><td>").append(reais(p.total)).append("</td></tr></table>");
        if(!p.logDetalhe.isEmpty())b.append("<p class='warn'>").append(esc(p.logDetalhe)).append("</p>");
        return b.toString();
    }
    private static void linha(StringBuilder b,String titulo,String valor){b.append("<tr><td>").append(esc(titulo)).append("</td><td>").append(esc(valor)).append("</td></tr>");}
    public static String cancelado(PedidoIntegrado p){return inicio("Pedido cancelado")+"<p>A compra nao foi confirmada; nenhum pagamento foi solicitado.</p>"+tabela(p)+fim();}
    public static String concluido(PedidoIntegrado p){return inicio("Pagamento aprovado")+"<p><strong>Bandeira:</strong> "+esc(p.bandeira)+" — cartao terminado em "+esc(p.cartaoFinal)+"</p>"+
            "<p><strong>Transacao:</strong> "+esc(p.transacao)+"</p>"+
            "<p><strong>Taxa da operadora:</strong> "+reais(p.taxaOperadora)+" (deduzida do repasse, nao acrescida ao cliente)</p>"+
            "<p><strong>Valor liquidado pela operadora:</strong> "+reais(p.recebidoOperadora)+"</p>"+
            tabela(p)+"<p class='warn'>Nota fiscal, S3, banco consolidado NewTec e e-mail ainda nao implementados neste escopo.</p>"+fim();}
}
