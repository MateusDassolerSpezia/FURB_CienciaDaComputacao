package br.furb.dsc;

import java.net.*;
import java.io.*;
import java.math.*;
import java.nio.charset.StandardCharsets;

/** Protocolo real de socket TCP: Visa PAY/OK e Master PAYMENT/PROCEED. */
public class ProcessarPagamento {
    public PedidoIntegrado realizar(PedidoIntegrado p) throws Exception {
        if(!p.confirmado)throw new SecurityException("Pedido nao confirmado. Pagamento bloqueado.");
        boolean visa="visa".equals(p.bandeira);
        String host=Configuracao.obter(visa?"visa.host":"master.host","127.0.0.1");
        int port=Configuracao.inteiro(visa?"visa.port":"master.port",visa?8900:8901);
        try(Socket socket=new Socket()) {
            socket.connect(new InetSocketAddress(host,port),5000);socket.setSoTimeout(10000);
            try(BufferedReader input=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));
                PrintWriter out=new PrintWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8),true)) {
                String greeting=input.readLine();
                if(greeting==null)throw new EOFException("Servico de cartao nao enviou saudacao");
                if(visa){
                    enviar(out,input,"PAY","OK");
                    enviar(out,input,p.numeroCartao,"OK");
                    enviar(out,input,p.nomeCartao,"OK");
                    enviar(out,input,p.validadeCartao,"OK");
                    enviar(out,input,p.total.toPlainString(),"OK");
                }else{
                    enviar(out,input,"PAYMENT","OK");
                    for(int i=0;i<16;i+=4)enviar(out,input,p.numeroCartao.substring(i,i+4),"PROCEED");
                    enviar(out,input,p.nomeCartao,"PROCEED");
                    enviar(out,input,p.validadeCartao,"PROCEED");
                    enviar(out,input,p.total.toPlainString(),"PROCEED");
                }
                enviar(out,input,"COMMIT","OK");
                String resposta=input.readLine();
                checarErro(resposta);
                String[] campos=resposta.split(":");
                if(campos.length != (visa?6:4))throw new IOException("Resposta de transacao malformada");
                p.transacao=campos[0];
                if(!p.transacao.matches("[0-9a-fA-F-]{20,40}"))throw new IOException("Identificador de transacao invalido");
                BigDecimal cobrado=new BigDecimal(campos[visa?4:2]);
                p.recebidoOperadora=new BigDecimal(campos[visa?5:3]).setScale(2,RoundingMode.HALF_UP);
                p.taxaOperadora=cobrado.subtract(p.recebidoOperadora).setScale(2,RoundingMode.HALF_UP);
                if(cobrado.subtract(p.total).abs().compareTo(new BigDecimal("0.02"))>0)throw new IOException("Cartao informou valor cobrado diferente do pedido");
                if(p.taxaOperadora.signum()<0)throw new IOException("Taxa da operadora negativa");
            }
        }
        return p;
    }
    private static void enviar(PrintWriter out,BufferedReader in,String dado,String esperado) throws IOException {
        out.println(dado);
        if(out.checkError())throw new IOException("Falha ao enviar comando ao servidor de cartao");
        String resposta=in.readLine();
        checarErro(resposta);
        if(!esperado.equals(resposta))throw new IOException("Resposta inesperada do servidor de cartao: "+resposta);
    }
    private static void checarErro(String resposta) throws IOException {
        if(resposta==null)throw new EOFException("Servico de cartao desconectou sem resposta");
        if(resposta.startsWith("ERROR "))throw new IOException("Operadora recusou pagamento: "+resposta);
    }
}
