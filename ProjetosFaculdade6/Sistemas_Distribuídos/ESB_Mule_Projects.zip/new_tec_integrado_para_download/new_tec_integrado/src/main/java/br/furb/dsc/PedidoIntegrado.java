package br.furb.dsc;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/** Contexto da mensagem que percorre os sub-flows ESB. */
public class PedidoIntegrado {
    public String cliente, email, cep, endereco, bairro, cidade, uf, complemento;
    public String bandeira, nomeCartao, numeroCartao, validadeCartao;
    public int domestico, seguranca, medico, ark, solar;
    public int descontoEstoqueBr, descontoEstoqueStark;
    public boolean estoqueConsultado;
    public String codigoBr = "-", codigoStark = "-";
    public BigDecimal brSemDesconto = BigDecimal.ZERO, starkSemDesconto = BigDecimal.ZERO;
    public BigDecimal brTotal = BigDecimal.ZERO, starkTotal = BigDecimal.ZERO;
    public BigDecimal frete = BigDecimal.ZERO, comissao = BigDecimal.ZERO, total = BigDecimal.ZERO;
    public String transacao = "", cartaoFinal = "";
    public BigDecimal taxaOperadora = BigDecimal.ZERO, recebidoOperadora = BigDecimal.ZERO;
    public boolean confirmado;
    public final Map<String,Integer> produtos = new LinkedHashMap<String,Integer>();
    public String logDetalhe = "";
    public void atualizarTotal() { total = brTotal.add(starkTotal).add(comissao).add(frete).setScale(2, BigDecimal.ROUND_HALF_UP); }
}
