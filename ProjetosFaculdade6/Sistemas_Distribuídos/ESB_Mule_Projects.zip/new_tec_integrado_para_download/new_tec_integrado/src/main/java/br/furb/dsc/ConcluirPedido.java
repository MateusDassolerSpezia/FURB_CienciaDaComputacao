package br.furb.dsc;

import java.util.Map;

/** No browser, resgata token, valida SIM/NAO, cobra UMA unica vez. */
public class ConcluirPedido {
    public String concluir(Map<String,String> params) throws Exception {
        if(params==null)throw new IllegalArgumentException("Formulario de confirmacao vazio");
        String token=params.get("token");
        if(token==null||!token.matches("[0-9a-f]{48}"))throw new IllegalArgumentException("Token da confirmacao invalido");
        PedidoIntegrado p=PedidosPendentes.obterRemovendo(token);
        try {
            boolean sim=ConfirmarPedido.respostaValida(params.get("resposta"));
            if(!sim)return HtmlPedido.cancelado(p);
            p.confirmado=true;
            new ProcessarPagamento().realizar(p);
            return HtmlPedido.concluido(p);
        } finally { p.numeroCartao=null; }
    }
}
