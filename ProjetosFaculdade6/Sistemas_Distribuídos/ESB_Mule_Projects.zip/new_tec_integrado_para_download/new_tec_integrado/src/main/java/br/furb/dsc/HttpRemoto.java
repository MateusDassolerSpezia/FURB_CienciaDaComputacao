package br.furb.dsc;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** REST/JSON e SOAP/XML via HTTP(S) com timeouts e verificacao de status. */
public final class HttpRemoto {
    private HttpRemoto() { }
    public static String get(String url) throws IOException { return request("GET",url,null,null); }
    public static String post(String url,String type,String body) throws IOException { return request("POST",url,type,body); }
    private static String request(String method,String url,String type,String body) throws IOException {
        HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(Configuracao.inteiro("http.timeout.ms",10000));
        conn.setReadTimeout(Configuracao.inteiro("http.timeout.ms",10000));
        conn.setRequestMethod(method);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("Accept", "application/json, text/xml, application/xml");
        try {
            if (body != null) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type",type + "; charset=UTF-8");
                byte[] data = body.getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(data.length);
                try(OutputStream out=conn.getOutputStream()) {out.write(data);}
            }
            int status = conn.getResponseCode();
            InputStream in = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String resposta = in == null ? "" : lerLimitado(in);
            if(status < 200 || status > 299 || status == 204 || resposta.trim().isEmpty())
                throw new IOException("Servico " + new URL(url).getHost() + " respondeu HTTP " + status + ": " + resposta.substring(0, Math.min(160,resposta.length())));
            return resposta;
        } finally { conn.disconnect(); }
    }
    private static String lerLimitado(InputStream in) throws IOException {
        try(InputStream input=in; ByteArrayOutputStream buffer=new ByteArrayOutputStream()) {
            byte[] b=new byte[4096]; int n; int total=0;
            while((n=input.read(b))!=-1) { total+=n; if(total>1024*1024) throw new IOException("Resposta HTTP acima de 1 MiB"); buffer.write(b,0,n); }
            return new String(buffer.toByteArray(),StandardCharsets.UTF_8);
        }
    }
}
