package br.furb.dsc;

import java.util.Map;

public class ConsultarCEP {
    public PedidoIntegrado consultar(PedidoIntegrado p) throws Exception {
        Map<String,String> cep=JsonPlano.ler(HttpRemoto.get(Configuracao.obter("cep.url","https://ws.homologacao.ufsc.br/CEPService/getCepInfo/")+p.cep));
        p.uf=JsonPlano.texto(cep,"uf").toUpperCase();
        p.cidade=JsonPlano.texto(cep,"localidade");
        p.bairro=JsonPlano.texto(cep,"bairro");
        String logradouro=JsonPlano.texto(cep,"logradouro");
        p.endereco=logradouro + (p.complemento.isEmpty()?"":", "+p.complemento);
        if(!p.uf.matches("[A-Z]{2}")) throw new IllegalArgumentException("Estado de entrega invalido");
        return p;
    }
}
