package br.furb.dsc;

import java.util.Map;

/** Nao simula o robo IoT; consulta os REST disponibilizados pela monitoracao. */
public class ConsultarEstoque {
    public PedidoIntegrado consultar(PedidoIntegrado p) throws Exception {
        String modo=Configuracao.obter("estoque.modo","desativado");
        if ("desativado".equalsIgnoreCase(modo)) { p.estoqueConsultado=false; return p; }
        if (!"remoto".equalsIgnoreCase(modo)) throw new IllegalArgumentException("estoque.modo deve ser desativado ou remoto");
        p.estoqueConsultado=true;
        if (p.domestico+p.seguranca+p.medico>0) {
            p.descontoEstoqueBr=desconto(Configuracao.obter("estoque.br.url","https://brrobotics.vercel.app/api"));
        }
        if(p.ark+p.solar>0) {
            p.descontoEstoqueStark=desconto(Configuracao.obter("estoque.stark.url","https://starksystem.vercel.app/api"));
        }
        return p;
    }
    private int desconto(String url) throws Exception {
        Map<String,String> json=JsonPlano.ler(HttpRemoto.get(url));
        int flag=Integer.parseInt(JsonPlano.texto(json,"desconto"));
        if(flag!=0&&flag!=1)throw new IllegalArgumentException("Flag do estoque deve ser 0 ou 1");
        return flag;
    }
}
