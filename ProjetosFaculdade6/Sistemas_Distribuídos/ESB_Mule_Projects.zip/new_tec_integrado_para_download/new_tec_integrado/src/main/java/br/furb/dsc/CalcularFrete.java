package br.furb.dsc;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Invoca o programa legado real por ProcessBuilder: binario + UF MAIUSCULA. */
public class CalcularFrete {
    public PedidoIntegrado calcular(PedidoIntegrado p) throws Exception {
        String executable=Configuracao.obter("frete.executable","COLOQUE_AQUI_O_CAMINHO_DO_EXECUTAVEL");
        File file=new File(executable);
        if(!file.isFile())throw new IOException("Executavel de frete ausente. Configure frete.executable em newtec-integracao.properties: " + executable);
        Process processo=new ProcessBuilder(file.getAbsolutePath(),p.uf).redirectErrorStream(true).start();
        if(!processo.waitFor(8,TimeUnit.SECONDS)) {processo.destroyForcibly();throw new IOException("Timeout executando calculoFrete");}
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        try(InputStream in=processo.getInputStream()){byte[] b=new byte[512];int n;while((n=in.read(b))!=-1){if(buffer.size()+n>4096)throw new IOException("Saida do frete longa demais");buffer.write(b,0,n);}}
        String output=new String(buffer.toByteArray(),StandardCharsets.UTF_8).trim();
        if(processo.exitValue()!=0)throw new IOException("Executavel frete retornou codigo "+processo.exitValue()+": "+output);
        if(!output.matches("-?\\d+(?:\\.\\d+)?"))throw new IOException("Saida invalida do frete: "+output);
        p.frete=new BigDecimal(output).setScale(2,BigDecimal.ROUND_HALF_UP);
        if(p.frete.signum()<0)throw new IllegalArgumentException("UF nao aceita pelo executavel de frete: "+p.uf);
        return p;
    }
}
