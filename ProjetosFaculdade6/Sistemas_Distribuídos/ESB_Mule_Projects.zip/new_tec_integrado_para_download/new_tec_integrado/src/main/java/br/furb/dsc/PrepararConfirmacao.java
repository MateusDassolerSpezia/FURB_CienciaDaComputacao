package br.furb.dsc;

/** Etapa de confirmacao antes de executar o pagamento via TCP. */
public class PrepararConfirmacao {
    public String preparar(PedidoIntegrado p) throws Exception {
        if("console".equalsIgnoreCase(Configuracao.obter("confirmacao.modo","browser"))) {
            boolean confirmar=new ConfirmarPedido().confirmarTeclado(p);
            if(!confirmar){p.numeroCartao=null;return HtmlPedido.cancelado(p);}
            p.confirmado=true;
            try { new ProcessarPagamento().realizar(p);return HtmlPedido.concluido(p); }
            finally {p.numeroCartao=null;}
        }
        String token=PedidosPendentes.guardar(p);
        return HtmlPedido.inicio("Revise e confirme a compra") + HtmlPedido.tabela(p) +
          "<h2>Deseja finalizar o pedido?</h2><p>Selecione SIM para autorizar a cobranca ou NAO para cancelar.</p>"+
          "<form action='/confirmar' method='post' accept-charset='UTF-8'><input type='hidden' name='token' value='"+token+"'>"+
          "<button class='sim' name='resposta' value='sim' type='submit'>SIM — Pagar</button>"+
          "<button class='nao' name='resposta' value='nao' type='submit'>NAO — Cancelar</button></form>"+
          "<p><small>Confirmacao valida por 10 minutos e somente uma vez.</small></p></main></body></html>";
    }
}
