package br.furb.dsc;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Criterios da pagina 3: desconto por item (>3), B2B e IoT, nesta ordem. */
public class CalcularDescontos {
    public PedidoIntegrado calcular(PedidoIntegrado p) {
        p.brSemDesconto=preco(p.domestico,900).add(preco(p.seguranca,1800)).add(preco(p.medico,2500));
        p.starkSemDesconto=preco(p.solar,1500).add(preco(p.ark,2500));
        BigDecimal br = precoComDesconto(p.domestico,900,25)
                .add(precoComDesconto(p.seguranca,1800,15))
                .add(precoComDesconto(p.medico,2500,10));
        BigDecimal stark=precoComDesconto(p.solar,1500,15).add(precoComDesconto(p.ark,2500,10));
        br=br.multiply(new BigDecimal("0.85"));
        stark=stark.multiply(new BigDecimal("0.90"));
        if(p.descontoEstoqueBr==1)br=br.multiply(new BigDecimal("0.95"));
        if(p.descontoEstoqueStark==1)stark=stark.multiply(new BigDecimal("0.95"));
        p.brTotal=br.setScale(2,RoundingMode.HALF_UP);
        p.starkTotal=stark.setScale(2,RoundingMode.HALF_UP);
        return p;
    }
    private BigDecimal preco(int qtd,int unitario) {return BigDecimal.valueOf(qtd).multiply(BigDecimal.valueOf(unitario));}
    private BigDecimal precoComDesconto(int qtd,int unitario,int percent) {
        BigDecimal p=preco(qtd,unitario);
        return qtd>3?p.multiply(BigDecimal.valueOf(100-percent).movePointLeft(2)):p;
    }
}
