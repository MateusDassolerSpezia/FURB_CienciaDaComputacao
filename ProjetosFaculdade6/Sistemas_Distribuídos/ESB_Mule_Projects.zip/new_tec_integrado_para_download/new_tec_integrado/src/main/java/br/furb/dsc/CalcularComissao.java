package br.furb.dsc;

import java.lang.reflect.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.rmi.Naming;

/** Chama a assinatura real calcularValorComComissao(float) via objeto remoto RMI. */
public class CalcularComissao {
    public PedidoIntegrado calcular(PedidoIntegrado p) throws Exception {
        BigDecimal base=p.brTotal.add(p.starkTotal);
        if(base.signum()==0)throw new IllegalArgumentException("Subtotal vazio");
        Object remoto=Naming.lookup(Configuracao.obter("rmi.url","rmi://127.0.0.1:11099/CalculoComissaoService"));
        Method metodo=null;
        for(Method m:remoto.getClass().getMethods()){
            if(m.getName().equals("calcularValorComComissao") && m.getParameterTypes().length==1 &&
              (m.getParameterTypes()[0]==float.class || m.getParameterTypes()[0]==Float.class)) {metodo=m;break;}
        }
        if(metodo==null)throw new NoSuchMethodException("Objeto RMI sem metodo calcularValorComComissao(float). Verifique o JAR da interface no classpath.");
        Object resp;
        try { resp=metodo.invoke(remoto,base.floatValue()); }
        catch(InvocationTargetException ex){throw new IllegalStateException("Falha no servidor RMI: "+ex.getTargetException(),ex.getTargetException());}
        if(!(resp instanceof Number))throw new IllegalStateException("Servico RMI nao retornou um numero");
        // RMI usa float, tolerancia de diferencas pequenas de representacao/rounding.
        BigDecimal comissaoComFloat=new BigDecimal(resp.toString()).subtract(base);
        BigDecimal taxaEsperada=new BigDecimal(Configuracao.obter("comissao.taxa.esperada","0.15"));
        BigDecimal comissaoEsperada=base.multiply(taxaEsperada).setScale(2,RoundingMode.HALF_UP);
        BigDecimal tolerancia=base.multiply(new BigDecimal("0.000001")).max(new BigDecimal("0.05"));
        if(Configuracao.booleano("comissao.validar",true) && comissaoComFloat.subtract(comissaoEsperada).abs().compareTo(tolerancia)>0)
            throw new IllegalStateException("RMI retornou comissao de R$ "+comissaoComFloat.setScale(2,RoundingMode.HALF_UP)+" mas o enunciado exige 15% (R$ "+comissaoEsperada+"). Ajuste o servico RMI antes de cobrar o cliente.");
        p.comissao=comissaoComFloat.setScale(2,RoundingMode.HALF_UP);
        p.atualizarTotal();
        return p;
    }
}
