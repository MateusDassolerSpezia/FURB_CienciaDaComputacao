package br.furb.dsc;

import java.math.BigDecimal;
import java.util.Map;

/** Usa os servicos verdadeiros em NetBeans/GlassFish e recolhe codigos gerados. */
public class RegistrarFornecedores {
    public PedidoIntegrado registrar(PedidoIntegrado p) throws Exception {
        if(p.domestico+p.seguranca+p.medico>0){
            String itens="Robo Domestico="+p.domestico+";Robo Seguranca="+p.seguranca+";Robo Medico="+p.medico;
            String json="{\"cliente\":\""+JsonPlano.esc(p.cliente)+"\",\"endereco\":\""+JsonPlano.esc(p.endereco)+"\",\"estado\":\""+p.uf+"\",\"itens\":\""+JsonPlano.esc(itens)+"\",\"total\":"+p.brTotal.toPlainString()+"}";
            Map<String,String> response=JsonPlano.ler(HttpRemoto.post(Configuracao.obter("br.url","http://127.0.0.1:8080/BrRobotics/rest/BrRoboticsService/inserirPedido"),"application/json",json));
            p.codigoBr=JsonPlano.texto(response,"codigo");
            if(p.codigoBr.trim().isEmpty())throw new IllegalArgumentException("Codigo BrRobotics vazio");
            // Em banco BrRobotics o total deve ser o ESB calculado (servico de origem apenas persiste).
            if(response.containsKey("total")) {
                BigDecimal recebido=new BigDecimal(response.get("total"));
                if(recebido.subtract(p.brTotal).abs().compareTo(new BigDecimal("0.05"))>0)
                    throw new IllegalStateException("BrRobotics devolveu total divergente do calculado: "+recebido);
            }
        }
        if(p.ark+p.solar>0){
            String itens="Reator Ark="+p.ark+";Reator Solar="+p.solar;
            String soap="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                    +"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.starksystem.com/\">"
                    +"<soapenv:Header/><soapenv:Body><ws:inserirPedido><pedido>"
                    +tag("cliente",p.cliente)+tag("endereco",p.endereco)+tag("estado",p.uf)
                    +tag("itens",itens)+tag("total",p.starkTotal.toPlainString())
                    +"</pedido></ws:inserirPedido></soapenv:Body></soapenv:Envelope>";
            String response=HttpRemoto.post(Configuracao.obter("stark.url","http://127.0.0.1:8080/StarkSystem/StarkSystemService"),"text/xml",soap);
            p.codigoStark=XmlSeguro.buscar(response,"codigo");
            // OBS: StarkSystemService.java de origem altera p.total para 32000 antes de gravar;
            // registrar este problema sem substituir o valor cobrado correto no ESB.
            try {
                BigDecimal totalGravado=new BigDecimal(XmlSeguro.buscar(response,"total"));
                if(totalGravado.subtract(p.starkTotal).abs().compareTo(new BigDecimal("0.05"))>0)
                    p.logDetalhe="AVISO: StarkSystem devolveu total "+totalGravado+" diferente de "+p.starkTotal+" (servico NetBeans deve ser corrigido para atender integralmente ao enunciado).";
            } catch (NumberFormatException ex) { throw new IllegalArgumentException("Total StarkSystem invalido",ex); }
        }
        return p;
    }
    private static String tag(String name,String text){return "<"+name+">"+XmlSeguro.escape(text)+"</"+name+">";}
}
