package br.furb.dsc;

import java.security.SecureRandom;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/** Apenas em memoria, token de uso unico, expiracao de 10 minutos; sem gravar PAN em logs/arquivos. */
public final class PedidosPendentes {
    private static final Map<String,Item> ITEMS=new ConcurrentHashMap<String,Item>();
    private static final SecureRandom RANDOM=new SecureRandom();
    private static final long TTL=10*60*1000;
    private PedidosPendentes() { }
    private static class Item {final PedidoIntegrado pedido;final long criado=System.currentTimeMillis();Item(PedidoIntegrado p){pedido=p;}}
    public static String guardar(PedidoIntegrado p){
        for(Map.Entry<String,Item> i:ITEMS.entrySet())if(System.currentTimeMillis()-i.getValue().criado>TTL){Item rem=ITEMS.remove(i.getKey());if(rem!=null)rem.pedido.numeroCartao=null;}
        if(ITEMS.size()>1000)throw new IllegalStateException("Fila de confirmacao cheia");
        byte[] bytes=new byte[24];RANDOM.nextBytes(bytes);
        StringBuilder token=new StringBuilder();for(byte b:bytes)token.append(String.format("%02x",b&255));
        ITEMS.put(token.toString(),new Item(p));return token.toString();
    }
    public static PedidoIntegrado obterRemovendo(String token){
        Item item=ITEMS.remove(token);
        if(item==null)throw new IllegalArgumentException("Pedido nao encontrado, ja confirmado ou expirado");
        if(System.currentTimeMillis()-item.criado>TTL){item.pedido.numeroCartao=null;throw new IllegalArgumentException("Confirmacao expirada: faca novo pedido");}
        return item.pedido;
    }
}
