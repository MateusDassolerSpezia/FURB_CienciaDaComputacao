package br.furb.dsc;

import java.util.*;
import java.util.regex.*;

/** Extrator restrito a objetos JSON planos (formato real dos provedores do trabalho). */
public final class JsonPlano {
    private static final Pattern PAR = Pattern.compile("\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"\\s*:\\s*(\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"|-?\\d+(?:\\.\\d+)?|true|false|null)");
    private JsonPlano() { }
    public static Map<String,String> ler(String json) {
        if (json == null || !json.trim().startsWith("{") || !json.trim().endsWith("}"))
            throw new IllegalArgumentException("Resposta JSON invalida");
        Map<String,String> dados = new HashMap<String,String>();
        Matcher m = PAR.matcher(json);
        while (m.find()) {
            String raw = m.group(3) != null ? m.group(3) : m.group(2);
            dados.put(desescapar(m.group(1)), desescapar(raw));
        }
        if (dados.isEmpty()) throw new IllegalArgumentException("Objeto JSON sem campos conhecidos");
        return dados;
    }
    public static String texto(Map<String,String> mapa, String nome) {
        String value = mapa.get(nome);
        if (value == null || "null".equals(value)) throw new IllegalArgumentException("Resposta sem campo obrigatorio: " + nome);
        return value;
    }
    public static String esc(String value) {
        if (value == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c: value.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\"");break;
                case '\\':sb.append("\\\\");break;
                case '\n':sb.append("\\n");break;
                case '\r':sb.append("\\r");break;
                case '\t':sb.append("\\t");break;
                default: if (c < 32) sb.append(String.format("\\u%04x", (int)c)); else sb.append(c);
            }
        }
        return sb.toString();
    }
    private static String desescapar(String value) {
        if (value == null) return null;
        StringBuilder out = new StringBuilder();
        for (int i=0;i<value.length();i++) {
            char c=value.charAt(i);
            if(c=='\\' && i+1<value.length()) {
                char n=value.charAt(++i);
                if(n=='u' && i+4<value.length()) {
                    try { out.append((char)Integer.parseInt(value.substring(i+1,i+5),16));i+=4; }
                    catch(NumberFormatException ex){out.append('?');}
                } else if(n=='n') out.append('\n'); else if(n=='t') out.append('\t');
                else if(n=='r') out.append('\r'); else out.append(n);
            } else out.append(c);
        }
        return out.toString();
    }
}
