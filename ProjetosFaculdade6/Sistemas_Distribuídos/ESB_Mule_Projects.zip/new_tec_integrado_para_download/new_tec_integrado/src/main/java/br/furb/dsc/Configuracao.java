package br.furb.dsc;

import java.io.*;
import java.util.Properties;

/** Parametros do ambiente (propriedades do app); nao armazena credenciais. */
public final class Configuracao {
    private static final Properties PROPS = new Properties();
    static {
        InputStream in = Configuracao.class.getClassLoader().getResourceAsStream("newtec-integracao.properties");
        try {
            if (in == null) {
                String home = System.getProperty("app.home", ".");
                File file = new File(home, "newtec-integracao.properties");
                if (file.exists()) in = new FileInputStream(file);
            }
            if (in != null) try (InputStream source = in) { PROPS.load(new InputStreamReader(source, "UTF-8")); }
        } catch (IOException ex) { throw new ExceptionInInitializerError(ex); }
    }
    private Configuracao() { }
    public static String obter(String chave, String padrao) {
        String value = System.getProperty("newtec." + chave);
        return value != null ? value.trim() : PROPS.getProperty(chave, padrao).trim();
    }
    public static int inteiro(String chave, int padrao) { return Integer.parseInt(obter(chave, "" + padrao)); }
    public static boolean booleano(String chave, boolean padrao) { return Boolean.parseBoolean(obter(chave, "" + padrao)); }
}
