package br.furb.dsc;

import java.io.*;
import java.nio.charset.StandardCharsets;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;

public final class XmlSeguro {
    private XmlSeguro(){ }
    public static String escape(String s){ if(s==null)return "";return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;"); }
    public static String buscar(String xml,String elemento) throws Exception {
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        factory.setXIncludeAware(false);
        Document document=factory.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        String fault=XPathFactory.newInstance().newXPath().evaluate("//*[local-name()='Fault']/*[local-name()='faultstring']/text()",document);
        if(fault!=null&&!fault.trim().isEmpty()) throw new IOException("SOAP Fault: "+fault);
        String code=XPathFactory.newInstance().newXPath().evaluate("//*[local-name()='return']/*[local-name()='"+elemento+"']/text()",document);
        if(code==null||code.trim().isEmpty())throw new IOException("SOAP sem campo esperado: "+elemento);
        return code.trim();
    }
}
