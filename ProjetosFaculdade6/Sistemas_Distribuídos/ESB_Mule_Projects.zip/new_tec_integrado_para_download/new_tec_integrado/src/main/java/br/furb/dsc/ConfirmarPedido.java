package br.furb.dsc;

import java.util.Scanner;

/**
 * Adaptacao funcional da classe de confirmacao disponibilizada pelo aluno.
 * No modo console, a pessoa digita SIM/NAO durante a execucao do flow.
 * No modo browser, a mesma validacao e aplicada a confirmacao de formulario.
 */
public class ConfirmarPedido {
    private static final Object CONSOLE_LOCK = new Object();
    private static Scanner scanner;

    public static boolean respostaValida(String resposta) {
        if(resposta==null)throw new IllegalArgumentException("Confirmacao ausente");
        String s=resposta.trim().toLowerCase(java.util.Locale.ROOT);
        if(s.equals("sim"))return true;
        if(s.equals("nao")||s.equals("não"))return false;
        throw new IllegalArgumentException("Responda SIM ou NAO para confirmar o pedido");
    }
    public boolean confirmarTeclado(PedidoIntegrado pedido) {
        synchronized(CONSOLE_LOCK) {
            if (System.in == null) throw new IllegalStateException("Entrada padrao indisponivel. Utilize confirmacao.modo=browser");
            if (scanner == null) scanner = new Scanner(System.in,"UTF-8");
            System.out.println("\n================== NEWTEC ==================");
            System.out.println("Comprador: " + pedido.cliente);
            System.out.println("BrRobotics: " + pedido.codigoBr + " / R$ " + pedido.brTotal);
            System.out.println("StarkSystem: " + pedido.codigoStark + " / R$ " + pedido.starkTotal);
            System.out.println("Frete: R$ " + pedido.frete);
            System.out.println("Comissao: R$ " + pedido.comissao);
            System.out.println("TOTAL: R$ " + pedido.total);
            System.out.println("Finalizar o pedido? [SIM ou NAO]");
            if(!scanner.hasNextLine())throw new IllegalStateException("Console sem entrada padrao. Configure confirmacao.modo=browser e reinicie o app.");
            return respostaValida(scanner.nextLine());
        }
    }
}
