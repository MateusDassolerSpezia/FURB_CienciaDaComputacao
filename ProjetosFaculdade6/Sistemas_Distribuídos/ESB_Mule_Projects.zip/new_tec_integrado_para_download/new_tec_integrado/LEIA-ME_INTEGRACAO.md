# NewTec — projeto `new_tec_integrado` (Mule ESB 3.9)

## Objetivo e escopo

Este é **um único projeto Mule 3.9** importável no Anypoint Studio, derivado exclusivamente do `new_tec` enviado. Os outros projetos Mule, NetBeans e Eclipse permanecem intactos; não estão embutidos/modificados neste ZIP. Ele faz a orquestração pelas etapas nomeadas no editor visual do Mule (sub-flows), que executam componentes Java adaptadores para protocolos externos.

Implementado:

1. Entrada de seis kits robô+reator, nome, CEP, endereço complementar e bandeira/cartão na página NewTec (`http://localhost:8085/`).
2. Consulta real ao serviço **REST de CEP** da UFSC. Obtém logradouro, bairro, cidade e UF (não usa UF informada manualmente).
3. Cálculo de preços e descontos conforme página 3 do enunciado: desconto unitário por quantidade **acima** de 3, depois desconto B2B (15% robôs, 10% reatores).
4. **Opcional**: chamada aos dois endpoints de estoque IoT REST, aplicando 5% a cada fornecedor quando retornar `desconto=1`. O padrão é `estoque.modo=desativado`, porque essa etapa ainda não faz parte da entrega solicitada. Ativar `remoto` quando desejar testá-la.
5. Execução do **programa legado de frete** de acordo com a UF, por `ProcessBuilder`, obtendo o valor do executável real.
6. Chamada real ao BrRobotics **REST/JSON** e StarkSystem **SOAP/XML** hospedados no GlassFish, obtendo seus códigos de pedido.
7. Comissão via **Java RMI** invocando `calcularValorComComissao(float)` no serviço do Eclipse, validando a exigência de **15%** do enunciado.
8. Confirmação humana SIM/NAO **antes do pagamento**; modo browser (padrão) ou console, utilizando a adaptação da classe de confirmação fornecida pelo aluno.
9. Processamento real dos protocolos proprietários **Visa (TCP 8900)** e **Mastercard (TCP 8901)** usando as implementações dos serviços Eclipse enviados. Registra identificador da transação, taxa da operadora, valores pagos/recebidos.
10. Exibição dos valores, códigos dos fornecedores e transação no navegador. Erros abortam o fluxo e são devolvidos ao navegador. Pagamento só ocorre após confirmação positiva.

Fora do escopo desta versão: desenvolver o robô de estoque, emitir nota fiscal, salvar o pedido consolidado no banco NewTec, subir arquivos para Amazon S3, enviar e-mail e gerar planilha. A tabela `PEDIDOS` de cada fornecedor continua gerenciada pelo próprio serviço NetBeans.

## Preparação e pré-requisitos (Windows)

- **Anypoint Studio + Mule Runtime 3.9.5 EE**, conforme a configuração original do projeto.
- **Java JDK 8**, compatível com as ferramentas legadas usadas. Compile/execute os projetos no runtime Java 8.
- **GlassFish**, com BrRobotics REST e StarkSystem SOAP publicados em `http://127.0.0.1:8080/`.
- **Derby Network Server**, normalmente porta 1527, com bancos BrRobotics e StarkSystem já criados (usuário/senha `root`/`root` de acordo com o material). Verifique se os códigos são gerados pelas tabelas conforme seus serviços esperam.
- **Serviço RMI de comissão** rodando em `127.0.0.1:11099`, nome `CalculoComissaoService`. O arquivo JAR que contém a **interface remota** também precisa estar acessível ao classloader do Mule (veja abaixo).
- **Executável original de frete** do professor, por exemplo `calculoFrete-win-x64.exe`. **Não veio nos ZIPs fornecidos**; é necessário obtê-lo e apontar o caminho.
- Servidores **Visa** (`:8900`) e **Mastercard** (`:8901`) rodando, caso deseje testar pagamentos das respectivas bandeiras.
- Acesso HTTP(S) ao serviço CEP UFSC e, se habilitar estoque remoto, às APIs de estoque dos fornecedores.

### Importação do projeto

1. Extraia `new_tec_integrado.zip` em uma pasta, preservando a pasta `new_tec_integrado`.
2. No Anypoint Studio: **File > Import > General > Existing Projects into Workspace**. Selecione a pasta onde você extraiu o ZIP.
3. Confirme que a configuração é Mule 3.9.5 EE e Java 8 em `mule-project.xml`/`.classpath`.
4. Abra `src/main/app/newtec-integracao.properties`, configure `frete.executable` com **caminho completo** do executável legado. Aceita barras normais em caminhos Windows: `C:/Ferramentas/NewTec/calculoFrete-win-x64.exe`.
5. Para RMI, **adicione ao Java Build Path e ao classloader do aplicativo Mule** o JAR que contém a interface remota do seu `CalculoComissaoService`, normalmente `calculocomissao-service-1.0.0-jar-with-dependencies.jar`. Esse JAR **não estava** nos ZIPs enviados. Não altere o pacote da interface remota (ele deve coincidir com o da implementação do serviço RMI).
6. Inicialize NetBeans/GlassFish e Derby, depois RMI, depois Visa e Mastercard.
7. Execute o projeto Mule integrado e abra `http://localhost:8085/`.

**Servidores Visa e Mastercard**: no ZIP `Eclipse.zip`, os respectivos JARs `*-jar-with-dependencies.jar` estão nas pastas `target`. Inicie cada um num terminal JDK 8, por exemplo:

```bat
java -jar visapayment-service-1.0.0-jar-with-dependencies.jar
java -jar mastercardpayment-service-1.0.0-jar-with-dependencies.jar
```

Execute os comandos nas pastas onde os JARs estão localizados, em terminais separados. Ou execute as classes `BootstrapVisaPayment` e `BootstrapMastercardPayment` diretamente pelo Eclipse.

## Formulário e etapas do fluxo

- `GET /` — página de compra e imagens.
- `POST /tratarForm` — pedido: validação > CEP > [estoque opcional] > descontos > frete > fornecedores > RMI > confirmação.
- `POST /confirmar` — recebe token de pedido e resposta SIM/NAO; **só se SIM** aciona Visa/Mastercard e conclui.
- Componentes de negócio: `ReceberPedido`, `ConsultarCEP`, `ConsultarEstoque`, `CalcularDescontos`, `CalcularFrete`, `RegistrarFornecedores`, `CalcularComissao`, `PrepararConfirmacao`, `ConcluirPedido`, `ProcessarPagamento`.

**Confirmação por teclado no console**, tal como a exigência do PDF: altere `confirmacao.modo=browser` para `confirmacao.modo=console` em `newtec-integracao.properties`, reinicie o Mule e envie o pedido. A classe `ConfirmarPedido` apresenta os totais, imprime `Finalizar o pedido? [SIM ou NAO]` e bloqueia a execução aguardando resposta na entrada padrão. **Importante:** algumas versões do console do Anypoint Studio não repassam entradas a `System.in`; se não for possível digitar, rode o Mule em terminal com stdin ligado ou mantenha o modo `browser`. No modo browser, o cliente confirma no navegador de modo explícito e o pagamento é acionado depois de SIM.

## Descontos e total

Regras do PDF de 2026/2, preços das peças:

| Fornecedor / Peça | Valor unitário | Desconto se quantidade > 3 | B2B adicional |
|---|---:|---:|---:|
| BrRobotics — robô doméstico | R$ 900 | 25% | 15% no subtotal de robôs |
| BrRobotics — robô de segurança | R$ 1.800 | 15% | 15% no subtotal de robôs |
| BrRobotics — robô médico | R$ 2.500 | 10% | 15% no subtotal de robôs |
| StarkSystem — reator solar | R$ 1.500 | 15% | 10% no subtotal de reatores |
| StarkSystem — reator Ark | R$ 2.500 | 10% | 10% no subtotal de reatores |

Os descontos por quantidade se aplicam a **cada tipo de peça** quando sua quantidade for **maior que três**. Em seguida incide B2B sobre o subtotal já descontado. Se habilitar o estoque, aplica mais 5% **por fornecedor**, quando a API daquele fornecedor retornar `desconto=1`.

`Comissao = 15% × (totalBr + totalStark)`, obtida via RMI, com verificação do valor retornado. `TotalCliente = totalBr + totalStark + comissao + frete`. A taxa da operadora é a diferença entre o total cobrado e o total que a Visa/Mastercard repassa ao lojista: **não se soma novamente ao valor cobrado do cliente**.

### Pontos que precisam de correção NOS SISTEMAS FORNECEDORES para cumprir literalmente o PDF

1. **StarkSystem**: o arquivo original `StarkSystem/src/java/com/starksystem/ws/StarkSystemService.java` usa `pedido.setTotal(32000.0)` antes de salvar. Isso faz com que os totais da base StarkSystem não correspondam à precificação da NewTec. A integração exibe um aviso ao detectar a divergência, mas **não altera o projeto NetBeans**, conforme solicitado. Para a conformidade integral, é necessário corrigir essa implementação em uma etapa separada.
2. **Descontos dentro dos webservices**: o PDF diz que os próprios serviços BrRobotics e StarkSystem devem calcular descontos. A versão atual calcula corretamente na camada de integração NewTec e envia os valores calculados; isso atende ao fluxo de compra solicitado, **mas não à exigência estrita de alterar os dois webservices**. Seria necessário alterar o código e fazer deploy dos fornecedores, se o professor exigir a localização exata dessa lógica.
3. **RMI 15%**: um serviço de comissão feito em aula pode estar configurado para **10%**. Se estiver, a compra será interrompida com mensagem explícita. **Não** desative `comissao.validar=true` para mascarar o problema; altere a implementação do RMI para 15% no projeto de origem, se necessário.
4. **Códigos no Derby**: as classes DAO fornecidas inserem o campo `CODIGO` usando um valor recebido, possivelmente nulo, esperando depois obter a chave gerada. Se a coluna do banco não estiver configurada corretamente para autogeração, o pedido pode falhar. Confira os comandos DDL e a configuração `IDENTITY`/geração de códigos realmente usados pelo Derby.
5. **Cancelamento e falhas**: segundo a sequência do enunciado, os pedidos de fornecedores são registrados **antes** da confirmação do cliente. Se o cliente cancelar ou ocorrer erro depois dessa etapa, esses registros externos podem continuar existentes. Não há serviço de estorno/cancelamento de fornecedores entre os arquivos enviados; **não há compensação distribuída automática**. Pagamento não ocorre quando a resposta é NAO.

O mesmo raciocínio vale para eventuais falhas de comunicação após um `COMMIT` TCP: se o servidor tiver autorizado e a resposta for perdida, o sistema não deve repetir automaticamente a cobrança. O token é consumido antes do envio para minimizar pagamentos duplicados.

## Requisitos de segurança para testes

- Use **apenas cartões fictícios de laboratório** com os serviços locais da disciplina. Não envie informações de cartões verdadeiros por HTTP/sem TLS nem armazene em produção. Os simuladores TCP podem imprimir os dados no próprio log.
- A confirmação do browser guarda temporariamente os dados em memória por **até 10 minutos** com token aleatório de **uso único**; são descartados após confirmar/cancelar. Não há persistência do pagamento nem token durável nesta versão.
- `ConfirmarPedido.java` foi reconstruída a partir da lógica enviada. O arquivo original foi preservado para consulta em `referencias/ConfirmarPedido_original_fornecido.java.txt` (não é compilável sozinho porque depende de modelos `br.ufsc.das` não incluídos).
- Todas as integrações têm timeout ou erro explícito; **nenhum valor é substituído silenciosamente por valor fictício** na execução padrão.

## Testes executados durante a preparação

- **Compilação** das classes com `javac --release 8` e validação de XML bem-formado: OK.
- **Integração TCP real**: serviços Visa e Mastercard dos JARs Eclipse enviados, transações simuladas com `252.43`: OK. Taxa Visa R$ 12,62 e Mastercard R$ 7,57 (valores calculados a partir das respostas de cada servidor). Teste de bloqueio de pagamento sem confirmação: OK.
- **Teste orquestrado**: servidores auxiliares de teste locais para CEP, estoque, BrRobotics REST, StarkSystem SOAP, RMI 15% e executável de frete, seguido de Visa TCP real: OK. Não é teste no Mule Runtime ou nos serviços reais do GlassFish/Derby/RMI do aluno.
- **Não foi possível validar** o deploy real no Anypoint Studio, a disponibilidade das URLs externas, os bancos Derby locais, a existência do executável de frete e a interface RMI ausentes do pacote. A validação final deverá ser executada no notebook com os serviços instalados.

## Estrutura importante

```text
new_tec_integrado/
  .project                  nome: new_tec_integrado
  mule-project.xml          Mule 3.9.5 EE
  src/main/app/
    new_tec_integrado.xml   fluxo Mule + sub-flows
    newtec-integracao.properties  endpoints e parametros
    mule-deploy.properties
    docroot/index.html      formulario completo
    docroot/images/         imagens originais
  src/main/java/br/furb/dsc/
    ReceberPedido.java
    ConsultarCEP.java
    ConsultarEstoque.java
    CalcularDescontos.java
    CalcularFrete.java
    RegistrarFornecedores.java
    CalcularComissao.java
    ConfirmarPedido.java
    PrepararConfirmacao.java
    ConcluirPedido.java
    ProcessarPagamento.java
    PedidoIntegrado.java
    HttpRemoto.java, JsonPlano.java, XmlSeguro.java, HtmlPedido.java, Configuracao.java
  referencias/
    ConfirmarPedido_original_fornecido.java.txt
```

Este ZIP inclui **somente o projeto integrado**, sem reempacotar nem alterar os serviços separados.
